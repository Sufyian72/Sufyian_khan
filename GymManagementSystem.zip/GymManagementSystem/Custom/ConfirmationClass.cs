﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    class ConfirmationClass
    {
        public static DialogResult Message()
        {
            return MessageBox.Show("Are You Sure!", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
        }
        public static DialogResult MESSAGE
        {
            get
            {
                return MessageBox.Show("Are You Sure!", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                ;
            }
        }
    }
}
