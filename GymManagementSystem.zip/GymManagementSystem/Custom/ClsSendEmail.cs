﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace GymManagementSystem.Custom
{
    class ClsSendEmail
    {
        public static int SendEmail(string From,string To,string Subject,string Body)
        {
            try
            {
                MailMessage obj = new MailMessage();
                obj.To.Add(To);
                obj.From = new MailAddress(From);
                obj.Subject = Subject;
                obj.Body = Body;
                obj.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Credentials = new NetworkCredential(From, "");
                smtp.EnableSsl = true;
                smtp.Send(obj);
                return 1;
            }
            catch 
            {
                return 0;
            }
        }
    }
}
