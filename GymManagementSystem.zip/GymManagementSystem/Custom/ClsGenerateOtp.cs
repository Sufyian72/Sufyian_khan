﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymManagementSystem.Custom
{
    class ClsGenerateOtp
    {
        public static string GenerateOtp()
        {
            string value = "0123456789";
            string OtpCode = "";
            int index;
            Random obj = new Random();
            for (int i = 0; i < value.Length; i++)
            {
                index = obj.Next(0, value.Length-1);
                OtpCode += value[index];
            }
            return OtpCode;
        }
    }
}
