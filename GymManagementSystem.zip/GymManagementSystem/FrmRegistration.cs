﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmRegistration : Form
    {
        public FrmRegistration()
        {
            InitializeComponent();
        }
        int UserID;
        public void Edit(string UserId, string UserName, string FirstName, string LastName, string Email, string Contact, string Cnic, string Gender, string Address, string Age, int Status, string UserRole, string Password)
        {
            UserID = Convert.ToInt32(UserId);
            txtFirstName.Text = FirstName;
            txtLastName.Text = LastName;
            txtUserName.Text = UserName;
            txtEmail.Text = Email;
            txtContact.Text = Contact;
            txtCnic.Text = Cnic;
            ddlGender.Text = Gender;
            txtAddress.Text = Address;
            txtAge.Text = Age;
            ddlStatus.Text = Status == 1 ? "Active" : "Inactive";
            ddlUserRole.Text = UserRole;
            txtPassword.Text = Password;
        }
        private void lblGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }

        private void lblViewUserList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmUserList obj = new FrmUserList();
            obj.ShowDialog();
            this.Close();
        }
        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtFirstName.Text == "")
                {
                    lblFirstName.Text = "Required";
                    txtFirstName.Focus();
                }
                else if (txtLastName.Text == "")
                {
                    lblLastName.Text = "Required";
                    txtLastName.Focus();
                }
                else if (lblUserName.Text == "Incorrect UserName")
                {
                    lblUserName.Text = "Check User Name";
                    txtUserName.Focus();
                }
                else if (txtUserName.Text == "")
                {
                    lblUserName.Text = "Required";
                    txtUserName.Focus();
                }
                else if (txtEmail.Text == "")
                {
                    lblEmail.Text = "Required";
                    txtEmail.Focus();
                }
                else if (txtContact.Text == "")
                {
                    lblContact.Text = "Required";
                    txtContact.Focus();
                }
                else if (txtCnic.Text == "")
                {
                    lblCnic.Text = "Required";
                    txtCnic.Focus();
                }
                else if (ddlGender.Text == "")
                {
                    lblGender.Text = "Required";
                    ddlGender.Focus();
                }
                else if (txtAddress.Text == "")
                {
                    lblAddress.Text = "Required";
                    txtAddress.Focus();
                }
                else if (txtAge.Text == "")
                {
                    lblAge.Text = "Required";
                    txtAge.Focus();
                }
                else if (ddlStatus.Text == "")
                {
                    lblStatus.Text = "Required";
                    ddlStatus.Focus();
                }
                else if (ddlUserRole.Text == "")
                {
                    lblUserRole.Text = "Required";
                    ddlUserRole.Focus();
                }
                else if (txtPassword.Text == "")
                {
                    lblPassword.Text = "Required";
                    txtPassword.Focus();
                }
                else
                {
                    string[] check = txtEmail.Text.Split('@');
                    if (txtEmail.Text.Contains("@gmail.com") == false || check[0] == "" || check[1] != "gmail.com")
                    {
                        MessageBox.Show("Use: example@gmail.com");
                    }
                    else
                    {
                        if (UserID > 0)
                        {
                            SqlParameter[] prm1 = new SqlParameter[3];
                            prm1[0] = new SqlParameter("@Type", 9);
                            prm1[1] = new SqlParameter("@UserId", UserID);
                            prm1[2] = new SqlParameter("@UserName", txtUserName.Text);
                            DataTable dt1 = DataAccess.SpGetData("SpUser", prm1);
                            SqlParameter[] prm2 = new SqlParameter[3];
                            prm2[0] = new SqlParameter("@Type", 9);
                            prm2[1] = new SqlParameter("@UserId", UserID);
                            prm2[2] = new SqlParameter("@Email", txtEmail.Text);
                            DataTable dt2 = DataAccess.SpGetData("SpUser", prm2);
                            SqlParameter[] prm3 = new SqlParameter[3];
                            prm3[0] = new SqlParameter("@Type", 9);
                            prm3[1] = new SqlParameter("@UserId", UserID);
                            prm3[2] = new SqlParameter("@Contact", txtContact.Text);
                            DataTable dt3 = DataAccess.SpGetData("SpUser", prm3);
                            SqlParameter[] prm4 = new SqlParameter[3];
                            prm4[0] = new SqlParameter("@Type", 9);
                            prm4[1] = new SqlParameter("@UserId", UserID);
                            prm4[2] = new SqlParameter("@Cnic", txtCnic.Text);
                            DataTable dt4 = DataAccess.SpGetData("SpUser", prm4);
                            if (dt1.Rows.Count > 0)
                            {
                                MessageBox.Show("This UserName is Already Exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else if (dt2.Rows.Count > 0)
                            {
                                MessageBox.Show("This Email is Already Exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else if (dt3.Rows.Count > 0)
                            {
                                MessageBox.Show("This Contact is Already Exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else if (dt4.Rows.Count > 0)
                            {
                                MessageBox.Show("This Cnic is Already Exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                                {
                                    SqlParameter[] prm = new SqlParameter[13];
                                    prm[0] = new SqlParameter("@Type", 2);
                                    prm[1] = new SqlParameter("@UserId", UserID);
                                    prm[2] = new SqlParameter("@FirstName", txtFirstName.Text);
                                    prm[3] = new SqlParameter("@LastName", txtLastName.Text);
                                    prm[4] = new SqlParameter("@UserName", txtUserName.Text);
                                    prm[5] = new SqlParameter("@Email", txtEmail.Text);
                                    prm[6] = new SqlParameter("@Contact", txtContact.Text);
                                    prm[7] = new SqlParameter("@Cnic", txtCnic.Text);
                                    prm[8] = new SqlParameter("@Gender", ddlGender.Text);
                                    prm[9] = new SqlParameter("@Address", txtAddress.Text);
                                    prm[10] = new SqlParameter("@Age", txtAge.Text);
                                    prm[11] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                                    prm[12] = new SqlParameter("@UserRole", ddlUserRole.Text);
                                    if (DataAccess.SpExecuteQuery("SpUser", prm)==1)
                                    {
                                        SqlParameter[] prmm = new SqlParameter[4];
                                        prmm[0] = new SqlParameter("@Type", 1);
                                        prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                        prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Updated This User:\'" + txtUserName.Text + "\' Record SuccessFully");
                                        prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                                        DataAccess.SpExecuteQuery("SpLog", prmm);
                                    } 
                                }
                            }
                        }
                        else
                        {

                            SqlParameter[] prm1 = new SqlParameter[2];
                            prm1[0] = new SqlParameter("@Type", 4);
                            prm1[1] = new SqlParameter("@UserName", txtUserName.Text);
                            DataTable dt1 = DataAccess.SpGetData("SpUser", prm1);
                            SqlParameter[] prm2 = new SqlParameter[2];
                            prm2[0] = new SqlParameter("@Type", 4);
                            prm2[1] = new SqlParameter("@Email", txtEmail.Text);
                            DataTable dt2 = DataAccess.SpGetData("SpUser", prm2);
                            SqlParameter[] prm3 = new SqlParameter[2];
                            prm3[0] = new SqlParameter("@Type", 4);
                            prm3[1] = new SqlParameter("@Contact", txtContact.Text);
                            DataTable dt3 = DataAccess.SpGetData("SpUser", prm3);
                            SqlParameter[] prm4 = new SqlParameter[2];
                            prm4[0] = new SqlParameter("@Type", 4);
                            prm4[1] = new SqlParameter("@Cnic", txtCnic.Text);
                            DataTable dt4 = DataAccess.SpGetData("SpUser", prm4);
                            if (dt1.Rows.Count > 0)
                            {
                                MessageBox.Show("This UserName is Already Exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else if (dt2.Rows.Count > 0)
                            {
                                MessageBox.Show("This Email is Already Exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else if (dt3.Rows.Count > 0)
                            {
                                MessageBox.Show("This Contact is Already Exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else if (dt4.Rows.Count > 0)
                            {
                                MessageBox.Show("This Cnic is Already Exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                                {
                                    SqlParameter[] prm = new SqlParameter[13];
                                    prm[0] = new SqlParameter("@Type", 1);
                                    prm[1] = new SqlParameter("@FirstName", txtFirstName.Text);
                                    prm[2] = new SqlParameter("@LastName", txtLastName.Text);
                                    prm[3] = new SqlParameter("@UserName", txtUserName.Text);
                                    prm[4] = new SqlParameter("@Email", txtEmail.Text);
                                    prm[5] = new SqlParameter("@Contact", txtContact.Text);
                                    prm[6] = new SqlParameter("@Cnic", txtCnic.Text);
                                    prm[7] = new SqlParameter("@Gender", ddlGender.Text);
                                    prm[8] = new SqlParameter("@Address", txtAddress.Text);
                                    prm[9] = new SqlParameter("@Age", txtAge.Text);
                                    prm[10] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                                    prm[11] = new SqlParameter("@UserRole", ddlUserRole.Text);
                                    prm[12] = new SqlParameter("@Password", txtPassword.Text);
                                    if (DataAccess.SpExecuteQuery("SpUser", prm) == 1)
                                    {
                                        SqlParameter[] prmm = new SqlParameter[4];
                                        prmm[0] = new SqlParameter("@Type", 1);
                                        prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                        prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Inserted This User:\'"+txtUserName.Text+"\' Record SuccessFully");
                                        prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                                        DataAccess.SpExecuteQuery("SpLog", prmm);
                                    }
                                }
                            }
                        }
                    }
                    //if (check[0] == "" || check[1] != "gmail.com")
                    //{
                    //    MessageBox.Show("Use: example@gmail.com");
                    //}
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message);
            }
            UserID = 0;
        }

        private void txtFirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtFirstName.Text.Length <= 14)
            {
                if (((e.KeyChar < 'A' || e.KeyChar > 'z') || e.KeyChar == 94 || e.KeyChar == 95 || e.KeyChar == 91 || e.KeyChar == 93 || e.KeyChar == 92) & e.KeyChar != 32 & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }
        private void txtLastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtLastName.Text.Length <= 14)
            {
                if (((e.KeyChar < 'A' || e.KeyChar > 'z') || e.KeyChar == 94 || e.KeyChar == 95 || e.KeyChar == 91 || e.KeyChar == 93 || e.KeyChar == 92) & e.KeyChar != 32 & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtUserName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtUserName.Text.Length <= 29)
            {
                if (((e.KeyChar < 'a' || e.KeyChar > 'z') || e.KeyChar == 94 || e.KeyChar == 91 || e.KeyChar == 93 || e.KeyChar == 92) & e.KeyChar != 95 & e.KeyChar != 8 & (e.KeyChar < 48 || e.KeyChar > 57))
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtContact_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtContact.Text.Length <= 10)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtCnic_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtCnic.Text.Length <= 12)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtAge.Text.Length <= 2)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtEmail_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtEmail.Text.Length <= 29)
            {
                if (((e.KeyChar < 'a' || e.KeyChar > 'z') || e.KeyChar == 94 || e.KeyChar == 91 || e.KeyChar == 93 || e.KeyChar == 92) & e.KeyChar != 64 & e.KeyChar != 46 & e.KeyChar != 8 & (e.KeyChar < 48 || e.KeyChar > 57))
                {
                    e.Handled = true;
                }
                if (e.KeyChar == '@')
                {
                    if (txtEmail.Text.Contains("@") == true)
                    {
                        e.Handled = true;
                    }
                }
                if (e.KeyChar == '.')
                {
                    if (txtEmail.Text.Contains(".") == true)
                    {
                        e.Handled = true;
                    }
                }

            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (lblUserName.Text == "Required")
                {
                    lblUserName.Text = "";
                }
                char check = txtUserName.Text[0];
                if (check != '_' & (check < 'a' || check > 'z'))
                {
                    lblUserName.Text = "Incorrect UserName";
                }
            }
            catch
            {
                lblUserName.Text = "";
            }

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            if (txtEmail.Text != "")
            {
                lblEmail.Text = "";
            }
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {
            if (txtFirstName.Text != "")
            {
                lblFirstName.Text = "";
            }
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {
            if (txtLastName.Text != "")
            {
                lblLastName.Text = "";
            }
        }

        private void txtContact_TextChanged(object sender, EventArgs e)
        {
            if (txtContact.Text != "")
            {
                lblContact.Text = "";
            }
        }

        private void txtCnic_TextChanged(object sender, EventArgs e)
        {
            if (txtCnic.Text != "")
            {
                lblCnic.Text = "";
            }
        }

        private void ddlGender_TextChanged(object sender, EventArgs e)
        {
            if (ddlGender.Text != "")
            {
                lblGender.Text = "";
            }
        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {
            if (txtAddress.Text != "")
            {
                lblAddress.Text = "";
            }
        }

        private void txtAge_TextChanged(object sender, EventArgs e)
        {
            if (txtAge.Text != "")
            {
                lblAge.Text = "";
            }
        }

        private void ddlStatus_TextChanged(object sender, EventArgs e)
        {
            if (ddlStatus.Text != "")
            {
                lblStatus.Text = "";
            }
        }

        private void ddlUserRole_TextChanged(object sender, EventArgs e)
        {
            if (ddlUserRole.Text != "")
            {
                lblUserRole.Text = "";
            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtPassword.Text != "")
            {
                lblPassword.Text = "";
            }
        }
    }
}
