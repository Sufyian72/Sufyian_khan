﻿
namespace GymManagementSystem
{
    partial class FrmExpense
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblViewUserList = new System.Windows.Forms.LinkLabel();
            this.ddlStatus = new System.Windows.Forms.ComboBox();
            this.ddlExpenseHeadName = new System.Windows.Forms.ComboBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.lblExpenseHeadName = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lblAmount = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblGoToLogin = new System.Windows.Forms.LinkLabel();
            this.lblExpense = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.txtExpense = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCross = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblViewUserList
            // 
            this.lblViewUserList.AutoSize = true;
            this.lblViewUserList.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewUserList.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.lblViewUserList.Location = new System.Drawing.Point(277, 433);
            this.lblViewUserList.Name = "lblViewUserList";
            this.lblViewUserList.Size = new System.Drawing.Size(107, 15);
            this.lblViewUserList.TabIndex = 134;
            this.lblViewUserList.TabStop = true;
            this.lblViewUserList.Text = "View Expense List?";
            this.lblViewUserList.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblViewUserList_LinkClicked);
            // 
            // ddlStatus
            // 
            this.ddlStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlStatus.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddlStatus.FormattingEnabled = true;
            this.ddlStatus.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.ddlStatus.Location = new System.Drawing.Point(538, 208);
            this.ddlStatus.Name = "ddlStatus";
            this.ddlStatus.Size = new System.Drawing.Size(241, 24);
            this.ddlStatus.TabIndex = 4;
            this.ddlStatus.TextChanged += new System.EventHandler(this.ddlStatus_TextChanged);
            // 
            // ddlExpenseHeadName
            // 
            this.ddlExpenseHeadName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlExpenseHeadName.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddlExpenseHeadName.FormattingEnabled = true;
            this.ddlExpenseHeadName.Location = new System.Drawing.Point(280, 154);
            this.ddlExpenseHeadName.Name = "ddlExpenseHeadName";
            this.ddlExpenseHeadName.Size = new System.Drawing.Size(241, 24);
            this.ddlExpenseHeadName.TabIndex = 1;
            this.ddlExpenseHeadName.SelectionChangeCommitted += new System.EventHandler(this.ddlExpenseHeadName_SelectionChangeCommitted);
            this.ddlExpenseHeadName.TextChanged += new System.EventHandler(this.ddlExpenseHeadName_TextChanged);
            this.ddlExpenseHeadName.Click += new System.EventHandler(this.ddlExpenseHeadName_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.Color.Red;
            this.lblStatus.Location = new System.Drawing.Point(737, 194);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 12);
            this.lblStatus.TabIndex = 126;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.label17.Location = new System.Drawing.Point(535, 190);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(46, 16);
            this.label17.TabIndex = 125;
            this.label17.Text = "Status";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.panel11.Location = new System.Drawing.Point(538, 231);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(241, 3);
            this.panel11.TabIndex = 127;
            // 
            // lblExpenseHeadName
            // 
            this.lblExpenseHeadName.AutoSize = true;
            this.lblExpenseHeadName.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpenseHeadName.ForeColor = System.Drawing.Color.Red;
            this.lblExpenseHeadName.Location = new System.Drawing.Point(479, 140);
            this.lblExpenseHeadName.Name = "lblExpenseHeadName";
            this.lblExpenseHeadName.Size = new System.Drawing.Size(0, 12);
            this.lblExpenseHeadName.TabIndex = 115;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.label11.Location = new System.Drawing.Point(277, 136);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 16);
            this.label11.TabIndex = 114;
            this.label11.Text = "Expense Head";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.panel8.Location = new System.Drawing.Point(280, 177);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(241, 3);
            this.panel8.TabIndex = 116;
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmount.ForeColor = System.Drawing.Color.Red;
            this.lblAmount.Location = new System.Drawing.Point(479, 195);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(0, 12);
            this.lblAmount.TabIndex = 104;
            // 
            // txtAmount
            // 
            this.txtAmount.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmount.Location = new System.Drawing.Point(280, 209);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(241, 23);
            this.txtAmount.TabIndex = 2;
            this.txtAmount.TextChanged += new System.EventHandler(this.txtAmount_TextChanged);
            this.txtAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAmount_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.label7.Location = new System.Drawing.Point(277, 190);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 16);
            this.label7.TabIndex = 102;
            this.label7.Text = "Amount";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.panel5.Location = new System.Drawing.Point(280, 231);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(241, 3);
            this.panel5.TabIndex = 105;
            // 
            // lblGoToLogin
            // 
            this.lblGoToLogin.AutoSize = true;
            this.lblGoToLogin.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGoToLogin.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.lblGoToLogin.Location = new System.Drawing.Point(722, 433);
            this.lblGoToLogin.Name = "lblGoToLogin";
            this.lblGoToLogin.Size = new System.Drawing.Size(76, 15);
            this.lblGoToLogin.TabIndex = 95;
            this.lblGoToLogin.TabStop = true;
            this.lblGoToLogin.Text = "Go To Login?";
            this.lblGoToLogin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblGoToLogin_LinkClicked);
            // 
            // lblExpense
            // 
            this.lblExpense.AutoSize = true;
            this.lblExpense.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpense.ForeColor = System.Drawing.Color.Red;
            this.lblExpense.Location = new System.Drawing.Point(737, 138);
            this.lblExpense.Name = "lblExpense";
            this.lblExpense.Size = new System.Drawing.Size(0, 12);
            this.lblExpense.TabIndex = 93;
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.btnSubmit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.btnSubmit.FlatAppearance.BorderSize = 0;
            this.btnSubmit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmit.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.ForeColor = System.Drawing.Color.White;
            this.btnSubmit.Location = new System.Drawing.Point(409, 270);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(241, 25);
            this.btnSubmit.TabIndex = 5;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(273, 450);
            this.panel1.TabIndex = 89;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(25, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(214, 99);
            this.label3.TabIndex = 11;
            this.label3.Text = "Change Password";
            // 
            // txtExpense
            // 
            this.txtExpense.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExpense.Location = new System.Drawing.Point(538, 154);
            this.txtExpense.Name = "txtExpense";
            this.txtExpense.Size = new System.Drawing.Size(241, 23);
            this.txtExpense.TabIndex = 3;
            this.txtExpense.TextChanged += new System.EventHandler(this.txtExpense_TextChanged);
            this.txtExpense.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtExpense_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.label1.Location = new System.Drawing.Point(535, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 16);
            this.label1.TabIndex = 86;
            this.label1.Text = "Expense";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.panel2.Location = new System.Drawing.Point(538, 176);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(241, 3);
            this.panel2.TabIndex = 96;
            // 
            // btnCross
            // 
            this.btnCross.BackgroundImage = global::GymManagementSystem.Properties.Resources.icons8_close_window_26px;
            this.btnCross.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCross.FlatAppearance.BorderSize = 0;
            this.btnCross.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCross.Location = new System.Drawing.Point(763, 2);
            this.btnCross.Name = "btnCross";
            this.btnCross.Size = new System.Drawing.Size(33, 35);
            this.btnCross.TabIndex = 135;
            this.btnCross.UseVisualStyleBackColor = true;
            this.btnCross.Click += new System.EventHandler(this.btnCross_Click_1);
            // 
            // FrmExpense
            // 
            this.AcceptButton = this.btnSubmit;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCross);
            this.Controls.Add(this.lblViewUserList);
            this.Controls.Add(this.ddlStatus);
            this.Controls.Add(this.ddlExpenseHeadName);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.lblExpenseHeadName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.lblGoToLogin);
            this.Controls.Add(this.lblExpense);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtExpense);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmExpense";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmExpense";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel lblViewUserList;
        private System.Windows.Forms.ComboBox ddlStatus;
        private System.Windows.Forms.ComboBox ddlExpenseHeadName;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label lblExpenseHeadName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.LinkLabel lblGoToLogin;
        private System.Windows.Forms.Label lblExpense;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtExpense;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnCross;
    }
}