﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmTrainer : Form
    {
        public FrmTrainer()
        {
            InitializeComponent();
        }
        int TrainerId;
        string TrainerName;
        public void Edit(string trainerid, string trainername, string trainercontact, string trainercnic,int status,string gender,string address,string trainertype)
        {
            TrainerId = Convert.ToInt32(trainerid);
            txtName.Text = trainername;
            TrainerName = trainername;
            txtContact.Text = trainercontact;
            txtCnic.Text = trainercnic;
            ddlGender.Text = gender;
            txtAddress.Text = address;
            ddlTrainerType.Text = trainertype;
            ddlStatus.Text = status == 1 ? "Active" : "Inactive";
        }
        private void ViewTrainerList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmTrainerList obj = new FrmTrainerList();
            obj.ShowDialog();
            this.Close();
        }

        private void lblGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtName.Text=="")
            {
                lblName.Text = "Required";
                txtName.Focus();
            }
            else if (txtContact.Text=="")
            {
                lblContact.Text = "Required";
                txtContact.Focus();
            }
            else if (txtCnic.Text=="")
            {
                lblCnic.Text = "Required";
                txtCnic.Focus();
            }
            else if (ddlStatus.Text=="")
            {
                lblStatus.Text = "Required";
                ddlStatus.Focus();
            }
            else if (ddlGender.Text=="")
            {
                lblGender.Text = "Required";
                ddlGender.Focus();
            }
            else if (txtAddress.Text=="")
            {
                lblAddress.Text = "Required";
                txtAddress.Focus();
            }
            else if (ddlTrainerType.Text=="")
            {
                lblTrainerType.Text = "Required";
                ddlTrainerType.Focus();
            }
            else
            {
                if (TrainerId > 0)
                {


                    if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                    {
                        SqlParameter[] prm = new SqlParameter[9];
                        prm[0] = new SqlParameter("@Type", 2);
                        prm[1] = new SqlParameter("@TrainerId", TrainerId);
                        prm[2] = new SqlParameter("@TrainerName", txtName.Text);
                        prm[3] = new SqlParameter("@TrainerContact", txtContact.Text);
                        prm[4] = new SqlParameter("@TrainerAddress", txtAddress.Text);
                        prm[5] = new SqlParameter("@TrainerGender", ddlGender.Text);
                        prm[6] = new SqlParameter("@TrainerType", ddlTrainerType.Text);
                        prm[7] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                        prm[8] = new SqlParameter("@Cnic",txtCnic.Text);
                        if (DataAccess.SpExecuteQuery("SpTrainer", prm) == 1)
                        {
                            if (txtName.Text != TrainerName)
                            {
                                TrainerName = txtName.Text;
                            }
                            SqlParameter[] prmm = new SqlParameter[4];
                            prmm[0] = new SqlParameter("@Type", 1);
                            prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                            prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Updated This Trainer:\'" + TrainerName + "\' Record SuccessFully");
                            prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                            DataAccess.SpExecuteQuery("SpLog", prmm);
                        }
                    }

                }
                else
                {
                    if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                    {
                        SqlParameter[] prm = new SqlParameter[8];
                        prm[0] = new SqlParameter("@Type", 1);
                        prm[1] = new SqlParameter("@TrainerName", txtName.Text);
                        prm[2] = new SqlParameter("@TrainerContact", txtContact.Text);
                        prm[3] = new SqlParameter("@TrainerAddress", txtAddress.Text);
                        prm[4] = new SqlParameter("@TrainerGender", ddlGender.Text);
                        prm[5] = new SqlParameter("@TrainerType", ddlTrainerType.Text);
                        prm[6] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                        prm[7] = new SqlParameter("@Cnic", txtCnic.Text);
                        if (DataAccess.SpExecuteQuery("SpTrainer", prm) == 1)
                        {
                            SqlParameter[] prmm = new SqlParameter[4];
                            prmm[0] = new SqlParameter("@Type", 1);
                            prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                            prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Inserted This Trainer:\'" + txtName.Text + "\' Record SuccessFully");
                            prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                            DataAccess.SpExecuteQuery("SpLog", prmm);
                        }
                    }
                }
                TrainerId = 0;
            }
        }

        private void btnCross_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtName.Text.Length <= 29)
            {
                if (((e.KeyChar < 'A' || e.KeyChar > 'z') || e.KeyChar == 94 || e.KeyChar == 95 || e.KeyChar == 91 || e.KeyChar == 93 || e.KeyChar == 92) & e.KeyChar != 32 & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtContact_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtContact.Text.Length <= 10)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtCnic_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtCnic.Text.Length <= 12)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            if (txtName.Text!="")
            {
                lblName.Text = "";
            }
        }

        private void txtContact_TextChanged(object sender, EventArgs e)
        {
            if (txtContact.Text!="")
            {
                lblContact.Text = "";
            }
        }

        private void txtCnic_TextChanged(object sender, EventArgs e)
        {
            if (txtCnic.Text!="")
            {
                lblCnic.Text = "";
            }
        }

        private void ddlStatus_TextChanged(object sender, EventArgs e)
        {
            if (ddlStatus.Text!="")
            {
                lblStatus.Text = "";
            }
        }

        private void ddlGender_TextChanged(object sender, EventArgs e)
        {
            if (ddlGender.Text!="")
            {
                lblGender.Text = "";
            }
        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {
            if (txtAddress.Text!="")
            {
                lblAddress.Text = "";
            }
        }

        private void ddlTrainerType_TextChanged(object sender, EventArgs e)
        {
            if (ddlTrainerType.Text!="")
            {
                lblTrainerType.Text = "";
            }
        }
    }
}
