﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmMachine : Form
    {
        public FrmMachine()
        {
            InitializeComponent();
        }
        int MachineId;
        string MachineName;
        public void Edit(string machineid, string machinename,string description, int Status)
        {
            MachineId = Convert.ToInt32(machineid);
            txtMachineName.Text = machinename;
            MachineName = machinename;
            txtDescription.Text = description;
            ddlStatus.Text = Status == 1 ? "Active" : "Inactive";
        }

        private void lblViewMachineList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmMachineList obj = new FrmMachineList();
            obj.ShowDialog();
            this.Close();
        }

        private void lblGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtMachineName.Text=="")
            {
                lblMachineName.Text = "Required";
                txtMachineName.Focus();
            }
            else if (txtDescription.Text=="")
            {
                lblDescription.Text = "Required";
                txtDescription.Focus();
            }
            else if (ddlStatus.Text=="")
            {
                lblStatus.Text = "Required";
                ddlStatus.Focus();
            }
            else
            {
                if (MachineId > 0)
                {
                    if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                    {
                        SqlParameter[] prm = new SqlParameter[5];
                        prm[0] = new SqlParameter("@Type", 2);
                        prm[1] = new SqlParameter("@MachineId", MachineId);
                        prm[2] = new SqlParameter("@Machine", txtMachineName.Text);
                        prm[3] = new SqlParameter("@Description", txtDescription.Text);
                        prm[4] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                        if (DataAccess.SpExecuteQuery("SpMachine", prm) == 1)
                        {
                            if (txtMachineName.Text != MachineName)
                            {
                                MachineName = txtMachineName.Text;
                            }
                            SqlParameter[] prmm = new SqlParameter[4];
                            prmm[0] = new SqlParameter("@Type", 1);
                            prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                            prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Updated This Machine:\'" + MachineName + "\' Record SuccessFully");
                            prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                            DataAccess.SpExecuteQuery("SpLog", prmm);
                        }
                    }

                }
                else
                {
                    if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                    {
                        SqlParameter[] prm = new SqlParameter[4];
                        prm[0] = new SqlParameter("@Type", 1);
                        prm[1] = new SqlParameter("@Machine", txtMachineName.Text);
                        prm[2] = new SqlParameter("@Description", txtDescription.Text);
                        prm[3] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                        if (DataAccess.SpExecuteQuery("SpMachine", prm) == 1)
                        {
                            SqlParameter[] prmm = new SqlParameter[4];
                            prmm[0] = new SqlParameter("@Type", 1);
                            prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                            prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Inserted This Machine:\'" + txtMachineName.Text + "\' Record SuccessFully");
                            prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                            DataAccess.SpExecuteQuery("SpLog", prmm);
                        }
                    }
                }
                MachineId = 0;
            }
        }

        private void txtMachineName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtMachineName.Text.Length <= 29)
            {
                if (((e.KeyChar < 'A' || e.KeyChar > 'z') || e.KeyChar == 94 || e.KeyChar == 95 || e.KeyChar == 91 || e.KeyChar == 93 || e.KeyChar == 92) & e.KeyChar != 32 & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtMachineName_TextChanged(object sender, EventArgs e)
        {
            if (txtMachineName.Text!="")
            {
                lblMachineName.Text = "";
            }
        }

        private void txtDescription_TextChanged(object sender, EventArgs e)
        {
            if (txtDescription.Text!="")
            {
                lblDescription.Text = "";
            }
        }

        private void ddlStatus_TextChanged(object sender, EventArgs e)
        {
            if (ddlStatus.Text!="")
            {
                lblStatus.Text = "";
            }
        }
    }
}
