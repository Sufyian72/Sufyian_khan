﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmExpenseHeadList : Form
    {
        public FrmExpenseHeadList()
        {
            InitializeComponent();
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvExpenseHeadList.DataSource = DataAccess.SpGetData("SpExpenseHead", prm);
            if (FrmLogin.UserRole == "Operator")
            {
                dgvExpenseHeadList.Columns[0].Visible = false;
                dgvExpenseHeadList.Columns[1].Visible = false;
            }
        }

        private void btnAddExpenseHead_Click(object sender, EventArgs e)
        {
            FrmExpenseHead obj = new FrmExpenseHead();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvExpenseHeadList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                {
                    int ExpenseHeadId = Convert.ToInt32(dgvExpenseHeadList.Rows[e.RowIndex].Cells["ExpenseHeadId"].Value);
                    if (ExpenseHeadId > 0)
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[2];
                            prm[0] = new SqlParameter("@Type", 3);//for Deletion
                            prm[1] = new SqlParameter("@ExpenseHeadId", ExpenseHeadId);
                            if (DataAccess.SpExecuteQuery("SpExpenseHead", prm) == 1)
                            {
                                SqlParameter[] prm1 = new SqlParameter[4];
                                prm1[0] = new SqlParameter("@Type", 1);
                                prm1[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prm1[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Deleted This ExpenseHead:\'" + dgvExpenseHeadList.Rows[e.RowIndex].Cells["ExpenseHead"].Value.ToString() + "\' Record SuccessFully");
                                prm1[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prm1);
                            }
                            SqlParameter[] prmm = new SqlParameter[1];
                            prmm[0] = new SqlParameter("@Type", 4);
                            dgvExpenseHeadList.DataSource = DataAccess.SpGetData("SpExpenseHead", prmm);
                        }
                    }
                }
                else if (e.ColumnIndex == 1)
                {
                    FrmExpenseHead obj = new FrmExpenseHead();
                    obj.Edit(dgvExpenseHeadList.Rows[e.RowIndex].Cells["ExpenseHeadId"].Value.ToString(), dgvExpenseHeadList.Rows[e.RowIndex].Cells["ExpenseHead"].Value.ToString(), Convert.ToInt32(dgvExpenseHeadList.Rows[e.RowIndex].Cells["Status"].Value));               obj.ShowDialog();
                    this.Close();
                }
            }
            catch
            {

            }
        }
        private void txtExpenseHead_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 5);//Type 8 for searching
            prm[1] = new SqlParameter("@ExpenseHead", txtExpenseHead.Text);
            dgvExpenseHeadList.DataSource = DataAccess.SpGetData("SpExpenseHead", prm);
        }
    }
}
