﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmLog : Form
    {
        public FrmLog()
        {
            InitializeComponent();
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvLogList.DataSource= DataAccess.SpGetData("SpLog", prm);
        }

        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dtToDate_ValueChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[3];
            prm[0] = new SqlParameter("@Type", 4);
            prm[1] = new SqlParameter("@FromDate", dtFromDate.Value);
            prm[2] = new SqlParameter("@ToDate", dtToDate.Value);
            dgvLogList.DataSource = DataAccess.SpGetData("SpLog", prm);
        }
    }
}
