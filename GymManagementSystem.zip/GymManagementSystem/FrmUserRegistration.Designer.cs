﻿
namespace GymManagementSystem
{
    partial class FrmUserRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRegister = new System.Windows.Forms.Button();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.txtcnic = new System.Windows.Forms.TextBox();
            this.txtcontact = new System.Windows.Forms.TextBox();
            this.txtlastname = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.txtconformpassword = new System.Windows.Forms.TextBox();
            this.txtage = new System.Windows.Forms.TextBox();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.lblgender = new System.Windows.Forms.Label();
            this.rdomale = new System.Windows.Forms.RadioButton();
            this.rdoother = new System.Windows.Forms.RadioButton();
            this.rdofemale = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnViewUserList = new System.Windows.Forms.LinkLabel();
            this.button1 = new System.Windows.Forms.Button();
            this.cmbrole = new System.Windows.Forms.ComboBox();
            this.lblconformpassword = new System.Windows.Forms.Label();
            this.lblstatus = new System.Windows.Forms.Label();
            this.cmbstatus = new System.Windows.Forms.ComboBox();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblrole = new System.Windows.Forms.Label();
            this.lblcnic = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.lblpassword = new System.Windows.Forms.Label();
            this.lbllastname = new System.Windows.Forms.Label();
            this.lblcontact = new System.Windows.Forms.Label();
            this.lblusername = new System.Windows.Forms.Label();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblage = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.Color.Yellow;
            this.btnRegister.FlatAppearance.BorderSize = 0;
            this.btnRegister.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRegister.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegister.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister.ForeColor = System.Drawing.Color.Black;
            this.btnRegister.Location = new System.Drawing.Point(313, 345);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(262, 34);
            this.btnRegister.TabIndex = 1;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // txtusername
            // 
            this.txtusername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.txtusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtusername.ForeColor = System.Drawing.Color.White;
            this.txtusername.Location = new System.Drawing.Point(23, 108);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(246, 26);
            this.txtusername.TabIndex = 3;
            this.txtusername.Text = "UserName";
            this.txtusername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtusername_KeyPress);
            // 
            // txtcnic
            // 
            this.txtcnic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.txtcnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcnic.ForeColor = System.Drawing.Color.White;
            this.txtcnic.Location = new System.Drawing.Point(21, 224);
            this.txtcnic.Name = "txtcnic";
            this.txtcnic.Size = new System.Drawing.Size(248, 26);
            this.txtcnic.TabIndex = 9;
            this.txtcnic.Text = "CNIC";
            this.txtcnic.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcnic_KeyPress);
            // 
            // txtcontact
            // 
            this.txtcontact.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.txtcontact.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcontact.ForeColor = System.Drawing.Color.White;
            this.txtcontact.Location = new System.Drawing.Point(21, 292);
            this.txtcontact.Name = "txtcontact";
            this.txtcontact.Size = new System.Drawing.Size(248, 26);
            this.txtcontact.TabIndex = 11;
            this.txtcontact.Text = "Contact";
            this.txtcontact.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcontact_KeyPress);
            // 
            // txtlastname
            // 
            this.txtlastname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.txtlastname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlastname.ForeColor = System.Drawing.Color.White;
            this.txtlastname.Location = new System.Drawing.Point(313, 46);
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.Size = new System.Drawing.Size(264, 26);
            this.txtlastname.TabIndex = 2;
            this.txtlastname.Text = "Name";
            this.txtlastname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtlastname_KeyPress);
            // 
            // txtemail
            // 
            this.txtemail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.ForeColor = System.Drawing.Color.White;
            this.txtemail.Location = new System.Drawing.Point(313, 109);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(264, 26);
            this.txtemail.TabIndex = 4;
            this.txtemail.Text = "Email";
            this.txtemail.TextChanged += new System.EventHandler(this.txtemail_TextChanged);
            this.txtemail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtemail_KeyPress);
            // 
            // txtpassword
            // 
            this.txtpassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.txtpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassword.ForeColor = System.Drawing.Color.White;
            this.txtpassword.Location = new System.Drawing.Point(313, 168);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(130, 26);
            this.txtpassword.TabIndex = 7;
            this.txtpassword.Text = "Password";
            this.txtpassword.TextChanged += new System.EventHandler(this.txtpassword_TextChanged);
            // 
            // txtconformpassword
            // 
            this.txtconformpassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.txtconformpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtconformpassword.ForeColor = System.Drawing.Color.White;
            this.txtconformpassword.Location = new System.Drawing.Point(449, 168);
            this.txtconformpassword.Name = "txtconformpassword";
            this.txtconformpassword.Size = new System.Drawing.Size(128, 26);
            this.txtconformpassword.TabIndex = 8;
            this.txtconformpassword.Text = "Conform";
            // 
            // txtage
            // 
            this.txtage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.txtage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtage.ForeColor = System.Drawing.Color.White;
            this.txtage.Location = new System.Drawing.Point(313, 224);
            this.txtage.Name = "txtage";
            this.txtage.Size = new System.Drawing.Size(264, 26);
            this.txtage.TabIndex = 12;
            this.txtage.Text = "Age";
            this.txtage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtage_KeyPress);
            // 
            // txtaddress
            // 
            this.txtaddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.txtaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddress.ForeColor = System.Drawing.Color.White;
            this.txtaddress.Location = new System.Drawing.Point(23, 350);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(246, 69);
            this.txtaddress.TabIndex = 10;
            this.txtaddress.Text = "Address";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgender.ForeColor = System.Drawing.Color.Aqua;
            this.lblgender.Location = new System.Drawing.Point(317, 273);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(63, 20);
            this.lblgender.TabIndex = 17;
            this.lblgender.Text = "Gender";
            // 
            // rdomale
            // 
            this.rdomale.AutoSize = true;
            this.rdomale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdomale.ForeColor = System.Drawing.Color.Aqua;
            this.rdomale.Location = new System.Drawing.Point(321, 296);
            this.rdomale.Name = "rdomale";
            this.rdomale.Size = new System.Drawing.Size(61, 24);
            this.rdomale.TabIndex = 14;
            this.rdomale.TabStop = true;
            this.rdomale.Text = "Male";
            this.rdomale.UseVisualStyleBackColor = true;
            this.rdomale.CheckedChanged += new System.EventHandler(this.rdomale_CheckedChanged);
            // 
            // rdoother
            // 
            this.rdoother.AutoSize = true;
            this.rdoother.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoother.ForeColor = System.Drawing.Color.Aqua;
            this.rdoother.Location = new System.Drawing.Point(505, 297);
            this.rdoother.Name = "rdoother";
            this.rdoother.Size = new System.Drawing.Size(67, 24);
            this.rdoother.TabIndex = 16;
            this.rdoother.TabStop = true;
            this.rdoother.Text = "Other";
            this.rdoother.UseVisualStyleBackColor = true;
            // 
            // rdofemale
            // 
            this.rdofemale.AutoSize = true;
            this.rdofemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdofemale.ForeColor = System.Drawing.Color.Aqua;
            this.rdofemale.Location = new System.Drawing.Point(407, 297);
            this.rdofemale.Name = "rdofemale";
            this.rdofemale.Size = new System.Drawing.Size(80, 24);
            this.rdofemale.TabIndex = 15;
            this.rdofemale.TabStop = true;
            this.rdofemale.Text = "Female";
            this.rdofemale.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnViewUserList);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.cmbrole);
            this.panel2.Controls.Add(this.lblconformpassword);
            this.panel2.Controls.Add(this.lblstatus);
            this.panel2.Controls.Add(this.cmbstatus);
            this.panel2.Controls.Add(this.rdofemale);
            this.panel2.Controls.Add(this.lbladdress);
            this.panel2.Controls.Add(this.lblrole);
            this.panel2.Controls.Add(this.lblcnic);
            this.panel2.Controls.Add(this.lblemail);
            this.panel2.Controls.Add(this.lblpassword);
            this.panel2.Controls.Add(this.lbllastname);
            this.panel2.Controls.Add(this.lblcontact);
            this.panel2.Controls.Add(this.lblusername);
            this.panel2.Controls.Add(this.txtfirstname);
            this.panel2.Controls.Add(this.lblFirstName);
            this.panel2.Controls.Add(this.txtpassword);
            this.panel2.Controls.Add(this.lblage);
            this.panel2.Controls.Add(this.rdoother);
            this.panel2.Controls.Add(this.txtconformpassword);
            this.panel2.Controls.Add(this.btnRegister);
            this.panel2.Controls.Add(this.rdomale);
            this.panel2.Controls.Add(this.txtusername);
            this.panel2.Controls.Add(this.txtemail);
            this.panel2.Controls.Add(this.lblgender);
            this.panel2.Controls.Add(this.txtcnic);
            this.panel2.Controls.Add(this.txtlastname);
            this.panel2.Controls.Add(this.txtaddress);
            this.panel2.Controls.Add(this.txtage);
            this.panel2.Controls.Add(this.txtcontact);
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(306, 41);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(599, 470);
            this.panel2.TabIndex = 3;
            // 
            // btnViewUserList
            // 
            this.btnViewUserList.BackColor = System.Drawing.Color.Yellow;
            this.btnViewUserList.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewUserList.ForeColor = System.Drawing.Color.Black;
            this.btnViewUserList.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.btnViewUserList.LinkColor = System.Drawing.Color.Black;
            this.btnViewUserList.Location = new System.Drawing.Point(313, 417);
            this.btnViewUserList.Name = "btnViewUserList";
            this.btnViewUserList.Size = new System.Drawing.Size(262, 33);
            this.btnViewUserList.TabIndex = 82;
            this.btnViewUserList.TabStop = true;
            this.btnViewUserList.Text = "View User List";
            this.btnViewUserList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnViewUserList.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.btnViewUserList_LinkClicked);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Yellow;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(313, 381);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(262, 34);
            this.button1.TabIndex = 35;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // cmbrole
            // 
            this.cmbrole.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.cmbrole.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbrole.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbrole.ForeColor = System.Drawing.Color.White;
            this.cmbrole.FormattingEnabled = true;
            this.cmbrole.Items.AddRange(new object[] {
            "Admin",
            "Operator"});
            this.cmbrole.Location = new System.Drawing.Point(160, 166);
            this.cmbrole.Name = "cmbrole";
            this.cmbrole.Size = new System.Drawing.Size(109, 28);
            this.cmbrole.TabIndex = 6;
            this.cmbrole.Text = "Role";
            // 
            // lblconformpassword
            // 
            this.lblconformpassword.AutoSize = true;
            this.lblconformpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblconformpassword.ForeColor = System.Drawing.Color.Aqua;
            this.lblconformpassword.Location = new System.Drawing.Point(434, 143);
            this.lblconformpassword.Name = "lblconformpassword";
            this.lblconformpassword.Size = new System.Drawing.Size(0, 20);
            this.lblconformpassword.TabIndex = 25;
            // 
            // lblstatus
            // 
            this.lblstatus.AutoSize = true;
            this.lblstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstatus.ForeColor = System.Drawing.Color.Aqua;
            this.lblstatus.Location = new System.Drawing.Point(22, 143);
            this.lblstatus.Name = "lblstatus";
            this.lblstatus.Size = new System.Drawing.Size(0, 20);
            this.lblstatus.TabIndex = 33;
            // 
            // cmbstatus
            // 
            this.cmbstatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.cmbstatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbstatus.ForeColor = System.Drawing.Color.White;
            this.cmbstatus.FormattingEnabled = true;
            this.cmbstatus.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.cmbstatus.Location = new System.Drawing.Point(23, 166);
            this.cmbstatus.Name = "cmbstatus";
            this.cmbstatus.Size = new System.Drawing.Size(124, 28);
            this.cmbstatus.TabIndex = 5;
            this.cmbstatus.Text = "Status";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdress.ForeColor = System.Drawing.Color.Aqua;
            this.lbladdress.Location = new System.Drawing.Point(22, 332);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(0, 20);
            this.lbladdress.TabIndex = 32;
            // 
            // lblrole
            // 
            this.lblrole.AutoSize = true;
            this.lblrole.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrole.ForeColor = System.Drawing.Color.Aqua;
            this.lblrole.Location = new System.Drawing.Point(147, 143);
            this.lblrole.Name = "lblrole";
            this.lblrole.Size = new System.Drawing.Size(0, 20);
            this.lblrole.TabIndex = 27;
            // 
            // lblcnic
            // 
            this.lblcnic.AutoSize = true;
            this.lblcnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcnic.ForeColor = System.Drawing.Color.Aqua;
            this.lblcnic.Location = new System.Drawing.Point(21, 207);
            this.lblcnic.Name = "lblcnic";
            this.lblcnic.Size = new System.Drawing.Size(0, 20);
            this.lblcnic.TabIndex = 31;
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.ForeColor = System.Drawing.Color.Aqua;
            this.lblemail.Location = new System.Drawing.Point(314, 85);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(0, 20);
            this.lblemail.TabIndex = 30;
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassword.ForeColor = System.Drawing.Color.Aqua;
            this.lblpassword.Location = new System.Drawing.Point(314, 142);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(0, 20);
            this.lblpassword.TabIndex = 34;
            // 
            // lbllastname
            // 
            this.lbllastname.AutoSize = true;
            this.lbllastname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllastname.ForeColor = System.Drawing.Color.Aqua;
            this.lbllastname.Location = new System.Drawing.Point(313, 23);
            this.lbllastname.Name = "lbllastname";
            this.lbllastname.Size = new System.Drawing.Size(0, 20);
            this.lbllastname.TabIndex = 29;
            // 
            // lblcontact
            // 
            this.lblcontact.AutoSize = true;
            this.lblcontact.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcontact.ForeColor = System.Drawing.Color.Aqua;
            this.lblcontact.Location = new System.Drawing.Point(22, 272);
            this.lblcontact.Name = "lblcontact";
            this.lblcontact.Size = new System.Drawing.Size(0, 20);
            this.lblcontact.TabIndex = 24;
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.ForeColor = System.Drawing.Color.Aqua;
            this.lblusername.Location = new System.Drawing.Point(22, 85);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(0, 20);
            this.lblusername.TabIndex = 23;
            // 
            // txtfirstname
            // 
            this.txtfirstname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.txtfirstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfirstname.ForeColor = System.Drawing.Color.White;
            this.txtfirstname.Location = new System.Drawing.Point(23, 46);
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(246, 26);
            this.txtfirstname.TabIndex = 2;
            this.txtfirstname.Text = "First Name";
            this.txtfirstname.Click += new System.EventHandler(this.txtfirstname_Click);
            this.txtfirstname.TextChanged += new System.EventHandler(this.txtfirstname_TextChanged);
            this.txtfirstname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfirstname_KeyPress);
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstName.ForeColor = System.Drawing.Color.Red;
            this.lblFirstName.Location = new System.Drawing.Point(21, 20);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(0, 20);
            this.lblFirstName.TabIndex = 21;
            // 
            // lblage
            // 
            this.lblage.AutoSize = true;
            this.lblage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblage.ForeColor = System.Drawing.Color.Aqua;
            this.lblage.Location = new System.Drawing.Point(309, 210);
            this.lblage.Name = "lblage";
            this.lblage.Size = new System.Drawing.Size(0, 20);
            this.lblage.TabIndex = 26;
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::GymManagementSystem.Properties.Resources.gym_pic_81;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(106, 41);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 470);
            this.panel1.TabIndex = 4;
            // 
            // FrmUserRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1006, 560);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmUserRegistration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.TextBox txtcnic;
        private System.Windows.Forms.TextBox txtcontact;
        private System.Windows.Forms.TextBox txtlastname;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.TextBox txtconformpassword;
        private System.Windows.Forms.TextBox txtage;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.RadioButton rdomale;
        private System.Windows.Forms.RadioButton rdoother;
        private System.Windows.Forms.RadioButton rdofemale;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.Label lblcontact;
        private System.Windows.Forms.Label lblconformpassword;
        private System.Windows.Forms.Label lblage;
        private System.Windows.Forms.Label lblrole;
        private System.Windows.Forms.Label lbllastname;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblcnic;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lblstatus;
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.ComboBox cmbrole;
        private System.Windows.Forms.ComboBox cmbstatus;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.LinkLabel btnViewUserList;
        private System.Windows.Forms.Button button1;
    }
}