﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmListTrainer : Form
    {
        public FrmListTrainer()
        {
            InitializeComponent();
            load();
        }
        public void load()
        {
           DgvTrainer.DataSource= DataAccess.GetData("select *from tblTrainer");
        }
        private void DgvUser_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int id;
            try
            {
                if (e.ColumnIndex == 0)
                {
                    id = Convert.ToInt32(DgvTrainer.Rows[e.RowIndex].Cells["TrainerId"].Value);
                    if (id > 0)
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[1];
                            prm[0] = new SqlParameter("@TrainerId", id);
                            DataAccess.ExecuteQuery("delete from tbltrainer where TrainerId=@TrainerId", prm);
                            load();
                        }
                    }
                }
                else if (e.ColumnIndex==1)
                {
                    id =Convert.ToInt32( DgvTrainer.Rows[e.RowIndex].Cells["Trainerid"].Value);
                    //string name = DgvTrainer.Rows[e.RowIndex].Cells["TrainerName"].Value.ToString();
                    //string address = DgvTrainer.Rows[e.RowIndex].Cells["TrainerrAddress"].Value.ToString();
                    Frmtrainer obj = new Frmtrainer();
                    obj.Edit(id);
                    //obj.Edit(name, address);
                    this.Hide();
                    obj.ShowDialog();
                }
            }
            catch 
            {

                MessageBox.Show("Click on Rows");
            }
            
        }
    }
}
