﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmExpenseList : Form
    {
        public FrmExpenseList()
        {
            InitializeComponent();
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvExpenseList.DataSource = DataAccess.SpGetData("SpExpense", prm);
            if (FrmLogin.UserRole == "Operator")
            {
                dgvExpenseList.Columns[0].Visible = false;
                dgvExpenseList.Columns[1].Visible = false;
            }
            LoadExpenseHead();
        }

        public void LoadExpenseHead()
        {
            DataTable dt = DataAccess.GetData("select *from TblExpenseHead");
            ddlExpenseHeadName.DataSource = dt;
            ddlExpenseHeadName.DisplayMember = "ExpenseHead";
            ddlExpenseHeadName.ValueMember = "ExpenseHeadId";
        }

        private void btnAddExpense_Click(object sender, EventArgs e)
        {
            FrmExpense obj = new FrmExpense();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvExpenseList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                {
                    int ExpenseId = Convert.ToInt32(dgvExpenseList.Rows[e.RowIndex].Cells["ExpenseId"].Value);
                    if (ExpenseId > 0)
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[2];
                            prm[0] = new SqlParameter("@Type", 3);//for Deletion
                            prm[1] = new SqlParameter("@ExpenseId", ExpenseId);
                            if (DataAccess.SpExecuteQuery("SpExpense", prm) == 1)
                            {
                                SqlParameter[] prm1 = new SqlParameter[4];
                                prm1[0] = new SqlParameter("@Type", 1);
                                prm1[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prm1[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Deleted This Expense:\'" + dgvExpenseList.Rows[e.RowIndex].Cells["Expense"].Value.ToString() + "\' Record SuccessFully");
                                prm1[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prm1);
                            }
                            SqlParameter[] prmm = new SqlParameter[1];
                            prmm[0] = new SqlParameter("@Type", 4);
                            dgvExpenseList.DataSource = DataAccess.SpGetData("SpExpense", prmm);
                        }
                    }
                }
                else if (e.ColumnIndex == 1)
                {
                    FrmExpense obj = new FrmExpense();
                    obj.Edit(dgvExpenseList.Rows[e.RowIndex].Cells["ExpenseId"].Value.ToString(), dgvExpenseList.Rows[e.RowIndex].Cells["Expense"].Value.ToString(), dgvExpenseList.Rows[e.RowIndex].Cells["ExpenseHeadId"].Value.ToString(), dgvExpenseList.Rows[e.RowIndex].Cells["Amount"].Value.ToString(), Convert.ToInt32(dgvExpenseList.Rows[e.RowIndex].Cells["Status"].Value));
                    obj.ShowDialog();
                    this.Close();
                }
            }
            catch
            {

            }
        }

  

        private void txtExpense_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 5);//Type 8 for searching
            prm[1] = new SqlParameter("@Expense", txtExpense.Text);
            dgvExpenseList.DataSource = DataAccess.SpGetData("SpExpense", prm);
        }

        private void ddlExpenseHeadName_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 5);//Type 8 for searching
            prm[1] = new SqlParameter("@ExpenseHead", ddlExpenseHeadName.Text);
            dgvExpenseList.DataSource = DataAccess.SpGetData("SpExpense", prm);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvExpenseList.DataSource = DataAccess.SpGetData("SpExpense", prm);
        }
    }
}
