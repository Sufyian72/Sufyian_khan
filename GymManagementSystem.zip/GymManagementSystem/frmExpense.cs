﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmExpense : Form
    {
        public FrmExpense()
        {
            InitializeComponent();
        }
        int ExpenseId;
        public void Edit(string expenseid, string expense, string expenseheadname, string amount, int Status)
        {
            LoadExpenseHead();
            ExpenseId = Convert.ToInt32(expenseid);
            ddlExpenseHeadName.SelectedValue = Convert.ToInt32(expenseheadname);
            txtExpense.Text = expense;
            ddlStatus.Text = Status == 1 ? "Active" : "Inactive";
            txtAmount.Text = amount;
        }
        public void LoadExpenseHead()
        {
            DataTable dt = DataAccess.GetData("select *from TblExpenseHead");
            ddlExpenseHeadName.DataSource = dt;
            ddlExpenseHeadName.DisplayMember = "ExpenseHead";
            ddlExpenseHeadName.ValueMember = "ExpenseHeadId";
        }
        private void lblViewUserList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmExpenseList obj = new FrmExpenseList();
            obj.ShowDialog();
            this.Close();
        }

        private void lblGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (ddlExpenseHeadName.Text == "")
            {
                lblExpenseHeadName.Text = "Required";
                ddlExpenseHeadName.Focus();
            }
            else if (txtAmount.Text == "")
            {
                lblAmount.Text = "Required";
                txtAmount.Focus();
            }
            else if (txtExpense.Text == "")
            {
                lblExpense.Text = "Required";
                txtExpense.Focus();
            }
            else if (ddlStatus.Text == "")
            {
                lblStatus.Text = "Required";
                ddlStatus.Focus();
            }
            else
            {
                if (ExpenseId > 0)
                {
                    if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                    {
                        SqlParameter[] prm = new SqlParameter[6];
                        prm[0] = new SqlParameter("@Type", 2);
                        prm[1] = new SqlParameter("@ExpenseId", ExpenseId);
                        prm[2] = new SqlParameter("@ExpenseHeadId", ddlExpenseHeadName.SelectedValue);
                        prm[3] = new SqlParameter("@Expense", txtExpense.Text);
                        prm[4] = new SqlParameter("@Amount", txtAmount.Text);
                        prm[5] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                        if (DataAccess.SpExecuteQuery("SpExpense", prm) == 1)
                        {
                            SqlParameter[] prmm = new SqlParameter[4];
                            prmm[0] = new SqlParameter("@Type", 1);
                            prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                            prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Updated This Expense:\'" + txtExpense.Text + "\' Record SuccessFully");
                            prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                            DataAccess.SpExecuteQuery("SpLog", prmm);
                        }
                    }
                }
                else
                {

                    if (DateTime.Now.ToString("30/MMMM/yyyy") == DateTime.Now.ToString("30/MMMM/yyyy"))
                    {
                        MessageBox.Show("Expense Only Add on Date:30 of every Month");
                    }
                    else
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[5];
                            prm[0] = new SqlParameter("@Type", 1);
                            prm[1] = new SqlParameter("@ExpenseHeadId", ddlExpenseHeadName.SelectedValue);
                            prm[2] = new SqlParameter("@Expense", txtExpense.Text);
                            prm[3] = new SqlParameter("@Amount", txtAmount.Text);
                            prm[4] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                            if (DataAccess.SpExecuteQuery("SpExpense", prm) == 1)
                            {
                                SqlParameter[] prmm = new SqlParameter[4];
                                prmm[0] = new SqlParameter("@Type", 1);
                                prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Inserted This Expense:\'" + txtExpense.Text + "\' Record SuccessFully");
                                prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prmm);
                            }
                        }
                    }
                }
                ExpenseId = 0;
            }
        }

        private void txtExpense_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtExpense.Text.Length <= 29)
            {
                if (((e.KeyChar < 'A' || e.KeyChar > 'z') || e.KeyChar == 94 || e.KeyChar == 95 || e.KeyChar == 91 || e.KeyChar == 93 || e.KeyChar == 92) & e.KeyChar != 32 & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtAmount.Text.Length <= 20)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void ddlExpenseHeadName_TextChanged(object sender, EventArgs e)
        {
            if (ddlExpenseHeadName.Text != "")
            {
                lblExpenseHeadName.Text = "";
            }
        }

        private void txtExpense_TextChanged(object sender, EventArgs e)
        {
            if (txtExpense.Text != "")
            {
                lblExpense.Text = "";
            }
        }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
            if (txtAmount.Text != "")
            {
                lblAmount.Text = "";
            }
        }

        private void ddlStatus_TextChanged(object sender, EventArgs e)
        {
            if (ddlStatus.Text != "")
            {
                lblStatus.Text = "";
            }
        }

        private void ddlExpenseHeadName_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (ddlExpenseHeadName.Text == "Salary")
            {
                txtAmount.Enabled = false;
                SqlParameter[] prm = new SqlParameter[2];
                prm[0] = new SqlParameter("@Type", 4);
                prm[1] = new SqlParameter("@SalaryDate", DateTime.Now.ToString("Y"));
                DataTable dt = DataAccess.SpGetData("SpSalary", prm);
                if (dt.Rows.Count > 0)
                {
                    int TotalSalary = 0;
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        TotalSalary += Convert.ToInt32(dt.Rows[i]["Amount"]);
                    }
                    txtAmount.Text = "" + TotalSalary;
                }
            }
        }

        private void ddlExpenseHeadName_Click(object sender, EventArgs e)
        {
            LoadExpenseHead();
        }
    }
}

