﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmMachineUseList : Form
    {
        public FrmMachineUseList()
        {
            InitializeComponent();
            LoadCustomer();
            LoadMachine();
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvMachineUseList.DataSource = DataAccess.SpGetData("SpMachineUse", prm);
            if (FrmLogin.UserRole == "Operator")
            {
                dgvMachineUseList.Columns[0].Visible = false;
                dgvMachineUseList.Columns[1].Visible = false;
            }
        }

        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvMachineUseList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                {
                    int MachineUseId = Convert.ToInt32(dgvMachineUseList.Rows[e.RowIndex].Cells["MachineUseId"].Value);
                    if (MachineUseId > 0)
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[2];
                            prm[0] = new SqlParameter("@Type", 3);//for Deletion
                            prm[1] = new SqlParameter("@MachineUseId", MachineUseId);
                            if (DataAccess.SpExecuteQuery("SpMachineUse", prm) == 1)
                            {
                                SqlParameter[] prm1 = new SqlParameter[4];
                                prm1[0] = new SqlParameter("@Type", 1);
                                prm1[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prm1[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is changed Record,Now This Customer:\'" + dgvMachineUseList.Rows[e.RowIndex].Cells["CustomerName"].Value.ToString() + "\' can't used This Machine:\'"+ dgvMachineUseList.Rows[e.RowIndex].Cells["Machine"].Value.ToString()+"\' more");
                                prm1[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prm1);
                            }
                            SqlParameter[] prmm = new SqlParameter[1];
                            prmm[0] = new SqlParameter("@Type", 4);
                            dgvMachineUseList.DataSource = DataAccess.SpGetData("SpMachineUse", prmm);
                        }
                    }
                }
                else if (e.ColumnIndex == 1)
                {
                    FrmMachineUse obj = new FrmMachineUse();
                    obj.Edit(dgvMachineUseList.Rows[e.RowIndex].Cells["MachineUseId"].Value.ToString(), dgvMachineUseList.Rows[e.RowIndex].Cells["MachineId"].Value.ToString(), dgvMachineUseList.Rows[e.RowIndex].Cells["CustomerId"].Value.ToString(),dgvMachineUseList.Rows[e.RowIndex].Cells["Time"].Value.ToString(), Convert.ToInt32( dgvMachineUseList.Rows[e.RowIndex].Cells["Status"].Value));
                    obj.ShowDialog();
                    this.Close();
                }
            }
            catch(Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }

        private void ddlMachineName_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 7);//Type 7 for searching
            prm[1] = new SqlParameter("@Machine", ddlMachineName.Text);
            dgvMachineUseList.DataSource = DataAccess.SpGetData("SpMachineUse", prm);
        }
        public void LoadMachine()
        {
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            ddlMachineName.DataSource = DataAccess.SpGetData("SpMachine", prm);
            ddlMachineName.DisplayMember = "Machine";
            ddlMachineName.ValueMember = "MachineId";
        }
        public void LoadCustomer()
        {
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            ddlCustomerName.DataSource = DataAccess.SpGetData("SpCustomer", prm);
            ddlCustomerName.DisplayMember = "CustomerName";
            ddlCustomerName.ValueMember = "CustomerId";
        }

        private void ddlCustomerName_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 7);//Type 7 for searching
            prm[1] = new SqlParameter("@CustomerName", ddlCustomerName.Text);
            dgvMachineUseList.DataSource = DataAccess.SpGetData("SpMachineUse", prm);

        }
    }
}
