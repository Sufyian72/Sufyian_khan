﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmSalaryList : Form
    {
        public FrmSalaryList()
        {
            InitializeComponent();
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvSalaryList.DataSource = DataAccess.SpGetData("SpSalary", prm);
            if (FrmLogin.UserRole == "Operator")
            {
                dgvSalaryList.Columns[0].Visible = false;
                dgvSalaryList.Columns[1].Visible = false;
            }
        }


        private void btnAddSalary_Click(object sender, EventArgs e)
        {
            FrmSalary obj = new FrmSalary();
            obj.ShowDialog();
            this.Close();
        }
       
        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        private void dgvSalaryList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                {
                    int SalaryId = Convert.ToInt32(dgvSalaryList.Rows[e.RowIndex].Cells["SalaryId"].Value);
                    if (SalaryId > 0)
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[2];
                            prm[0] = new SqlParameter("@Type", 3);//for Deletion
                            prm[1] = new SqlParameter("@SalaryId", SalaryId);
                            if (DataAccess.SpExecuteQuery("SpSalary", prm) == 1)
                            {
                                SqlParameter[] prm1 = new SqlParameter[4];
                                prm1[0] = new SqlParameter("@Type", 1);
                                prm1[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prm1[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Deleted This Trainer :\'" + dgvSalaryList.Rows[e.RowIndex].Cells["TrainerName"].Value.ToString() + "\'(" + dgvSalaryList.Rows[e.RowIndex].Cells["TrainerId"].Value + ") " + "Salary :\'" + dgvSalaryList.Rows[e.RowIndex].Cells["Amount"].Value + "\' Record SuccessFully");
                                prm1[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prm1);
                            }
                            SqlParameter[] prmm = new SqlParameter[1];
                            prmm[0] = new SqlParameter("@Type", 4);
                            dgvSalaryList.DataSource = DataAccess.SpGetData("SpSalary", prmm);
                        }
                    }
                }
                else if (e.ColumnIndex == 1)
                {

                    FrmSalary obj = new FrmSalary();
                    if (CheckTrainers==1)
                    {
                    obj.Edit("0", dgvSalaryList.Rows[e.RowIndex].Cells["TrainerId"].Value.ToString(),0, DateTime.Now.ToString());
                    }
                    else
                    {
                        obj.Edit(dgvSalaryList.Rows[e.RowIndex].Cells["SalaryId"].Value.ToString(), dgvSalaryList.Rows[e.RowIndex].Cells["TrainerId"].Value.ToString(), Convert.ToInt32(dgvSalaryList.Rows[e.RowIndex].Cells["Amount"].Value), dgvSalaryList.Rows[e.RowIndex].Cells["SalaryDate"].Value.ToString());
                    }
                    obj.ShowDialog();
                    this.Close();
                    CheckTrainers = 0;
                }
            }
            catch
            {

            }
        }

        private void dtSalaryDate_ValueChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 4);//Type 8 for searching
            prm[1] = new SqlParameter("@SalaryDate", dtSalaryDate.Value.ToString("Y"));
            dgvSalaryList.DataSource = DataAccess.SpGetData("SpSalary", prm);
        }
        int CheckTrainers = 0;
        private void dtSearchTrainersPendingSalary_ValueChanged(object sender, EventArgs e)
        {
            CheckTrainers = 1;
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 4);//Type 4 for searching
            prm[1] = new SqlParameter("@SalaryDate", dtSearchTrainersPendingSalary.Value.ToString("Y"));
            DataTable dt = DataAccess.SpGetData("SpSalary", prm);
            if (dt.Rows.Count > 0)
            {
                //FrmTrainerPendingSalary obj = new FrmTrainerPendingSalary();
                //obj.TrainersPendingSalary(dt);
                //obj.ShowDialog();
                //this.Close();
                string Query;
                int Length = dt.Rows.Count;
                if (Length > 1)
                {
                    //select *from Tbl where 
                    Query = "select *from TblTrainer where   ";
                    int i;
                    for (i = 0; i < Length - 1; i++)
                    {
                        Query += " TrainerId<>" + dt.Rows[i]["TrainerId"] + " and ";
                    }
                    if (i + 1 == Length)
                    {
                        Query += " TrainerId<>" + dt.Rows[i]["TrainerId"];
                    }
                }
                else
                {
                    Query = "select *from TblTrainer where TrainerId<>" + dt.Rows[0]["TrainerId"];
                }
                dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(Query, "data source=SAEEDULLAH\\SQLEXPRESS01;initial catalog=DbGymManagementSystem;integrated security=true");
                da.Fill(dt);
                dgvSalaryList.DataSource = dt;
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvSalaryList.DataSource = DataAccess.SpGetData("SpSalary", prm);
        }
    }
}
