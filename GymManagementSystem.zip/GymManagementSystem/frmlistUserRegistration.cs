﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class frmlistUserRegistration : Form
    {
        public frmlistUserRegistration()
        {

            InitializeComponent();
            DgvUser.DataSource = DataAccess.GetData("select *from TblUser");
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                {
                    int Userid = Convert.ToInt32(DgvUser.Rows[e.RowIndex].Cells["UserId"].Value);
                    if (Userid != 0)
                    {

                        DialogResult d = MessageBox.Show("Are You Sure!", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        if (d == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[1];
                            prm[0] = new SqlParameter("@UserId", DgvUser.Rows[e.RowIndex].Cells["UserId"].Value);
                            string Query = "delete from TblUser where UserId=@Userid";
                            DataAccess.ExecuteQuery(Query, prm);
                            DgvUser.DataSource = DataAccess.GetData("select *from TblUser");
                        }
                    }
                }
                else if (e.ColumnIndex==1)
                {
                    int Userid = Convert.ToInt32(DgvUser.Rows[e.RowIndex].Cells["UserId"].Value);
                    FrmUserRegistration obj = new FrmUserRegistration();
                    obj.Edit(Userid);
                    this.Hide();
                    obj.ShowDialog();
                }
            }
            catch
            {
                MessageBox.Show("Row Py CLick Kary");
            }

        }

        private void btnAddUser_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmUserRegistration obj = new FrmUserRegistration();
            this.Hide();
            obj.ShowDialog();
        }

        //private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //{

        //}
    }
}
