﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmTrainerList : Form
    {
        public FrmTrainerList()
        {
            InitializeComponent();
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvTrainerList.DataSource = DataAccess.SpGetData("SpTrainer", prm);
            if (FrmLogin.UserRole == "Operator")
            {
                dgvTrainerList.Columns[0].Visible = false;
                dgvTrainerList.Columns[1].Visible = false;
            }
        }

      

        private void btnAddTrainer_Click(object sender, EventArgs e)
        {
            FrmTrainer obj = new FrmTrainer();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvTrainerList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                {
                    int TrainerId = Convert.ToInt32(dgvTrainerList.Rows[e.RowIndex].Cells["TrainerId"].Value);
                    if (TrainerId > 0)
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[2];
                            prm[0] = new SqlParameter("@Type", 3);//for Deletion
                            prm[1] = new SqlParameter("@TrainerId", TrainerId);
                            if (DataAccess.SpExecuteQuery("SpTrainer", prm) == 1)
                            {
                                SqlParameter[] prm1 = new SqlParameter[4];
                                prm1[0] = new SqlParameter("@Type", 1);
                                prm1[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prm1[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Deleted This Trainer:\'" + dgvTrainerList.Rows[e.RowIndex].Cells["TrainerName"].Value.ToString() + "\' Record SuccessFully");
                                prm1[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prm1);
                            }
                            SqlParameter[] prmm = new SqlParameter[1];
                            prmm[0] = new SqlParameter("@Type", 4);
                            dgvTrainerList.DataSource = DataAccess.SpGetData("SpTrainer", prmm);
                        }
                    }
                }
                else if (e.ColumnIndex == 1)
                {
                    FrmTrainer obj = new FrmTrainer();
                    obj.Edit(dgvTrainerList.Rows[e.RowIndex].Cells["TrainerId"].Value.ToString(), dgvTrainerList.Rows[e.RowIndex].Cells["TrainerName"].Value.ToString(), dgvTrainerList.Rows[e.RowIndex].Cells["TrainerContact"].Value.ToString(), dgvTrainerList.Rows[e.RowIndex].Cells["Cnic"].Value.ToString(),  Convert.ToInt32(dgvTrainerList.Rows[e.RowIndex].Cells["Status"].Value), dgvTrainerList.Rows[e.RowIndex].Cells["TrainerGender"].Value.ToString(), dgvTrainerList.Rows[e.RowIndex].Cells["TrainerAddress"].Value.ToString(), dgvTrainerList.Rows[e.RowIndex].Cells["TrainerType"].Value.ToString());
                    obj.ShowDialog();
                    this.Close();
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 5);//Type 8 for searching
            prm[1] = new SqlParameter("@TrainerName", txtName.Text);
            dgvTrainerList.DataSource = DataAccess.SpGetData("SpTrainer", prm);
        }

        private void txtContact_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 5);//Type 8 for searching
            prm[1] = new SqlParameter("@TrainerContact", txtContact.Text);
            dgvTrainerList.DataSource = DataAccess.SpGetData("SpTrainer", prm);
        }

        private void ddlTrainerType_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 5);//Type 8 for searching
            prm[1] = new SqlParameter("@TrainerType", ddlTrainerType.Text);
            dgvTrainerList.DataSource = DataAccess.SpGetData("SpTrainer", prm);
        }
    }
}
