﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmUserList : Form
    {
        public FrmUserList()
        {
            InitializeComponent();
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvUserList.DataSource = DataAccess.SpGetData("SpUser", prm);
            if (FrmLogin.UserRole=="Operator")
            {
                dgvUserList.Columns[0].Visible = false;
                dgvUserList.Columns[1].Visible = false;
            }
        }
        private void btnAddUser_Click(object sender, EventArgs e)
        {
            FrmRegistration obj = new FrmRegistration();
            obj.ShowDialog();
            this.Close();
        }
        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void txtUserName_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 8);//Type 8 for searching
            prm[1] = new SqlParameter("@UserName", txtUserName.Text);
            dgvUserList.DataSource = DataAccess.SpGetData("SpUser", prm);
        }
        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 8);//Type 8 for searching
            prm[1] = new SqlParameter("@Email", txtEmail.Text);
            dgvUserList.DataSource = DataAccess.SpGetData("SpUser", prm);
        }
        private void txtContact_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 8);//Type 8 for searching
            prm[1] = new SqlParameter("@Contact", txtContact.Text);
            dgvUserList.DataSource = DataAccess.SpGetData("SpUser", prm);
        }
        private void dgvUserList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                {
                    int UserId =Convert.ToInt32( dgvUserList.Rows[e.RowIndex].Cells["UserId"].Value);
                    if (UserId>0)
                    {
                        if (ConfirmationClass.MESSAGE==DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[2];
                            prm[0] = new SqlParameter("@Type", 3);//for Deletion
                            prm[1] = new SqlParameter("@UserId", UserId);
                            if (DataAccess.SpExecuteQuery("SpUser", prm) == 1)
                            {
                                SqlParameter[] prm1 = new SqlParameter[4];
                                prm1[0] = new SqlParameter("@Type", 1);
                                prm1[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prm1[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Deleted This User:\'"+dgvUserList.Rows[e.RowIndex].Cells["UserName"].Value.ToString()+"\' Record SuccessFully");
                                prm1[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prm1);
                            }
                            SqlParameter[] prmm = new SqlParameter[1];
                            prmm[0] = new SqlParameter("@Type", 4);
                            dgvUserList.DataSource = DataAccess.SpGetData("SpUser", prmm);
                        }
                    }
                }
                else if (e.ColumnIndex==1)
                {
                    FrmRegistration obj = new FrmRegistration();
                    obj.Edit(dgvUserList.Rows[e.RowIndex].Cells["UserId"].Value.ToString(), dgvUserList.Rows[e.RowIndex].Cells["UserName"].Value.ToString(), dgvUserList.Rows[e.RowIndex].Cells["FirstName"].Value.ToString(), dgvUserList.Rows[e.RowIndex].Cells["LastName"].Value.ToString(), dgvUserList.Rows[e.RowIndex].Cells["Email"].Value.ToString(), dgvUserList.Rows[e.RowIndex].Cells["Contact"].Value.ToString(), dgvUserList.Rows[e.RowIndex].Cells["Cnic"].Value.ToString(), dgvUserList.Rows[e.RowIndex].Cells["Gender"].Value.ToString(), dgvUserList.Rows[e.RowIndex].Cells["Address"].Value.ToString(), dgvUserList.Rows[e.RowIndex].Cells["Age"].Value.ToString(), Convert.ToInt32( dgvUserList.Rows[e.RowIndex].Cells["Status"].Value), dgvUserList.Rows[e.RowIndex].Cells["UserRole"].Value.ToString(), dgvUserList.Rows[e.RowIndex].Cells["Password"].Value.ToString());
                    obj.ShowDialog();
                    this.Close();
                }
            }
            catch
            {

            }
        }
    }
}
