﻿using GymManagementSystem.Custom;
using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmGenerateOtp : Form
    {
        public FrmGenerateOtp()
        {
            InitializeComponent();
        }

        private void lblGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        public static string Otp, Email,UserName;
        public static int UserId;
        private void btnGenerateOtp_Click(object sender, EventArgs e)
        {
            if (txtEmail.Text=="")
            {
                lblEmail.Text = "Required";
                txtEmail.Focus();
            }
            else
            {
                SqlParameter[] prm1 = new SqlParameter[2];
                prm1[0] = new SqlParameter("@Type", 4);
                prm1[1] = new SqlParameter("@Email", txtEmail.Text);
                DataTable dt = DataAccess.SpGetData("SpUser", prm1);
                if (dt.Rows.Count>0)
                {
                    UserId =Convert.ToInt32( dt.Rows[0]["UserId"]);
                    UserName =""+( dt.Rows[0]["UserName"]);
                    Email = txtEmail.Text;
                    Otp = ClsGenerateOtp.GenerateOtp();
                    if (ClsSendEmail.SendEmail("", txtEmail.Text, "OTP", "Don't Share Your Otp Code:" + Otp + " with someone") == 1)
                    {
                        SqlParameter[] prm = new SqlParameter[3];
                        prm[0] = new SqlParameter("@Type", 5);
                        prm[1] = new SqlParameter("@Email", txtEmail.Text);
                        prm[2] = new SqlParameter("@Otp", Otp);
                        if (DataAccess.SpExecuteQuery("SpUser", prm) == 1)
                        {
                            FrmForgetPassword obj = new FrmForgetPassword();
                            obj.ShowDialog();
                            this.Close();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Incorrect Email Address","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }

            }
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            if (txtEmail.Text!="")
            {
                lblEmail.Text = "";
            }
        }
    }
}
