﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmMachineUse : Form
    {
        public FrmMachineUse()
        {
            InitializeComponent();
            LoadMachine();
            LoadCustomer();
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 5);//Select Latest Customer
            //CustomerId = Convert.ToInt32(DataAccess.SpGetData("SpCustomer", prm).Rows[0]["MaximumId"]);
            DataTable dt = DataAccess.SpGetData("SpCustomer", prm);
            CustomerId =Convert.ToInt32(dt.Rows[0]["MaximumId"]);
            SqlParameter[] prm1 = new SqlParameter[2];
            prm1[0] = new SqlParameter("@Type", 4);
            prm1[1] = new SqlParameter("@CustomerId", CustomerId);
            dt = DataAccess.SpGetData("SpCustomer", prm1);
            ddlCustomerName.SelectedValue = dt.Rows[0]["CustomerId"];
        }
        string CustomerName, MachineName;
        int MachineUseId, CustomerId;
        public void LoadMachine()
        {
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            ddlMachineName.DataSource = DataAccess.SpGetData("SpMachine", prm);
            ddlMachineName.DisplayMember = "Machine";
            ddlMachineName.ValueMember = "MachineId";
        }
        public void LoadCustomer()
        {
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            ddlCustomerName.DataSource = DataAccess.SpGetData("SpCustomer", prm);
            ddlCustomerName.DisplayMember = "CustomerName";
            ddlCustomerName.ValueMember = "CustomerId";
        }
        public void Edit(string machineuseid, string machinename, string customername, string time, int Status)
        {
            MachineName = machinename;
            CustomerName = customername;
            MachineUseId = Convert.ToInt32(machineuseid);
            ddlMachineName.SelectedValue = machinename;
            ddlCustomerName.SelectedValue = customername;
            dtTime.Value =Convert.ToDateTime(time);
            ddlStatus.Text = Status == 1 ? "Active" : "Inactive";
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (ddlMachineName.Text == "")
            {
                lblMachineName.Text = "Required";
                ddlMachineName.Focus();
            }
            else if (ddlCustomerName.Text == "")
            {
                lblCustomerName.Text = "Required";
                ddlCustomerName.Focus();
            }
            else if (ddlStatus.Text == "")
            {
                lblStatus.Text = "Required";
                ddlStatus.Focus();
            }
            else
            {
                if (MachineUseId > 0)
                {
                    SqlParameter[] prm1 = new SqlParameter[4];
                    prm1[0] = new SqlParameter("@Type", 6);
                    prm1[1] = new SqlParameter("@MachineUseId", MachineUseId);
                    prm1[2] = new SqlParameter("@Time", dtTime.Value);
                    prm1[3] = new SqlParameter("@MachineId", ddlMachineName.SelectedValue);
                    DataTable dt1 = DataAccess.SpGetData("SpMachineUse", prm1);
                    if (Convert.ToInt32(dt1.Rows[0]["Customers"]) > 5)
                    {
                        MessageBox.Show("Other Customers Already Use That Time", "Select Another Machine or Time", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[6];
                            prm[0] = new SqlParameter("@Type", 2);
                            prm[1] = new SqlParameter("@MachineUseId", MachineUseId);
                            prm[2] = new SqlParameter("@CustomerId", ddlCustomerName.SelectedValue);
                            prm[3] = new SqlParameter("@MachineId", ddlMachineName.SelectedValue);
                            prm[4] = new SqlParameter("@Time", dtTime.Value);
                            prm[5] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                            if (DataAccess.SpExecuteQuery("SpMachineUse", prm) == 1)
                            {
                                SqlParameter[] prmm = new SqlParameter[4];
                                prmm[0] = new SqlParameter("@Type", 1);
                                prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is changed Record,Now This Customer:\'" + CustomerName + "\' is Used This Machine:" + MachineName);
                                prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prmm);
                            }
                        }
                    }
                }
                else
                {
                    SqlParameter[] prm1 = new SqlParameter[3];
                    prm1[0] = new SqlParameter("@Type", 8);
                    prm1[1] = new SqlParameter("@Time", dtTime.Value);
                    prm1[2] = new SqlParameter("@MachineId", ddlMachineName.SelectedValue);
                    DataTable dt1 = DataAccess.SpGetData("SpMachineUse", prm1);
                    if (Convert.ToInt32(dt1.Rows[0]["Customers"]) > 5)
                    {
                        MessageBox.Show("Other Customers Already Use That Time", "Select Another Machine or Time", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[5];
                            prm[0] = new SqlParameter("@Type", 1);
                            prm[1] = new SqlParameter("@CustomerId", ddlCustomerName.SelectedValue);
                            prm[2] = new SqlParameter("@MachineId", ddlMachineName.SelectedValue);
                            prm[3] = new SqlParameter("@Time", dtTime.Value);
                            prm[4] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                            if (DataAccess.SpExecuteQuery("SpMachineUse", prm) == 1)
                            {
                                SqlParameter[] prmm = new SqlParameter[4];
                                prmm[0] = new SqlParameter("@Type", 1);
                                prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is allowed This Customer:\'" + ddlCustomerName.Text + "\' To Used This Machine:\'" + ddlMachineName.Text + "\'");
                                prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prmm);
                            }
                        }
                    }
                }
                MachineUseId = 0;
            }
        }

        private void ddlMachineName_TextChanged(object sender, EventArgs e)
        {
            if (ddlMachineName.Text != "")
            {
                lblMachineName.Text = "";
            }
        }

        private void ddlCustomerName_TextChanged(object sender, EventArgs e)
        {
            if (ddlCustomerName.Text != "")
            {
                lblCustomerName.Text = "";
            }
        }

        private void lblViewMachineUseList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmMachineUseList obj = new FrmMachineUseList();
            obj.ShowDialog();
            this.Close();
        }

        private void lblGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ddlStatus_TextChanged(object sender, EventArgs e)
        {
            if (ddlStatus.Text != "")
            {
                lblStatus.Text = "";
            }
        }
    }
}
