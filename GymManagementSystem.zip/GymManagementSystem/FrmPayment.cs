﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmPayment : Form
    {
        public FrmPayment()
        {
            InitializeComponent();
        }
        public void LoadCustomer()
        {
            DataTable dt = DataAccess.GetData("select *from TblCustomer");
            ddlCustomerName.DataSource = dt;
            ddlCustomerName.DisplayMember = "CustomerName";
            ddlCustomerName.ValueMember = "CustomerId";
        }
        int PaymentId,Amount;
        public void Edit(string paymentid, string customername, int amount, string paymentdate)
        {
            txtAmount.Enabled = true;
            LoadCustomer();
            PaymentId = Convert.ToInt32(paymentid);
            ddlCustomerName.SelectedValue = Convert.ToInt32(customername);
            txtAmount.Text = "" + amount;
            Amount = amount;
            dtPaymentDate.Value = Convert.ToDateTime(paymentdate);
            if (paymentid==""+ 0)
            {
                 amount = 0;
                SqlParameter[] prm = new SqlParameter[3];
                prm[0] = new SqlParameter("@Type", 4);
                prm[1] = new SqlParameter("@CustomerId", ddlCustomerName.SelectedValue);
                prm[2] = new SqlParameter("@Status", 1);
                DataTable dt = DataAccess.SpGetData("SpCustomer", prm);
                if (dt.Rows.Count > 0)
                {
                    prm[0] = new SqlParameter("@Type", 4);
                    prm[1] = new SqlParameter("@TrainerId", dt.Rows[0]["TrainerId"]);
                    prm[2] = new SqlParameter("@Status", 1);
                    dt = DataAccess.SpGetData("SpTrainer", prm);
                    if (dt.Rows.Count > 0)
                    {
                        if ("" + dt.Rows[0]["TrainerType"] == "Personal")
                        {
                            amount = 500;
                        }
                        prm[0] = new SqlParameter("@Type", 4);
                        prm[1] = new SqlParameter("@CustomerId", ddlCustomerName.SelectedValue);
                        prm[2] = new SqlParameter("@Status", 1);
                        dt = DataAccess.SpGetData("SpMachineUse", prm);
                        if (dt.Rows.Count > 0)
                        {
                            amount += dt.Rows.Count * 1000;
                        }
                    }
                }
                txtAmount.Text = "" + (amount + 1000);
            }
        }
        private void lblViewPaymentList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmPaymentList obj = new FrmPaymentList();
            obj.ShowDialog();
            this.Close();
        }

        private void lblGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (ddlCustomerName.Text=="")
            {
                lblCustomerName.Text = "Select Customer";
            }
            else if (txtAmount.Text=="")
            {
                lblAmount.Text = "Enter Amount";
            }
            else
            {
                if (PaymentId > 0)
                {


                    if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                    {
                        SqlParameter[] prm = new SqlParameter[5];
                        prm[0] = new SqlParameter("@Type", 2);
                        prm[1] = new SqlParameter("@PaymentId", PaymentId);
                        prm[2] = new SqlParameter("@CustomerId", ddlCustomerName.SelectedValue);
                        prm[3] = new SqlParameter("@Amount", txtAmount.Text);
                        prm[4] = new SqlParameter("@PaymentDate", dtPaymentDate.Value.ToString("Y"));
                        if (DataAccess.SpExecuteQuery("SpPayment", prm) == 1)
                        {
                            SqlParameter[] prmm = new SqlParameter[4];
                            prmm[0] = new SqlParameter("@Type", 1);
                            prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                            if (txtAmount.Text != "" + Amount)
                            {
                                prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Updated This Customer :\'" + ddlCustomerName.Text + "(" + ddlCustomerName.SelectedValue + ")\' Payment From This :\'" + Amount + "\' To This :\'" + txtAmount.Text + "\' SuccessFully");
                            }
                            else
                            {
                                prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Updated This Customer :\'" + ddlCustomerName.Text + "(" + ddlCustomerName.SelectedValue + ")\' Payment Record SuccessFully");
                            }
                            prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                            DataAccess.SpExecuteQuery("SpLog", prmm);
                        }
                    }
                    txtAmount.Enabled = false;
                }
                else
                {
                    SqlParameter[] parameters = new SqlParameter[3];
                    parameters[0] = new SqlParameter("@Type", 4);
                    parameters[1] = new SqlParameter("@CustomerId", ddlCustomerName.SelectedValue);
                    parameters[2] = new SqlParameter("@PaymentDate", dtPaymentDate.Value.ToString("Y"));
                    DataTable dt = DataAccess.SpGetData("SpPayment", parameters);
                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("Already Paid for this Month");
                    }
                    else
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[4];
                            prm[0] = new SqlParameter("@Type", 1);
                            prm[1] = new SqlParameter("@CustomerId", ddlCustomerName.SelectedValue);
                            prm[2] = new SqlParameter("@Amount", txtAmount.Text);
                            prm[3] = new SqlParameter("@PaymentDate", dtPaymentDate.Value.ToString("Y"));
                            if (DataAccess.SpExecuteQuery("SpPayment", prm) == 1)
                            {
                                SqlParameter[] prmm = new SqlParameter[4];
                                prmm[0] = new SqlParameter("@Type", 1);
                                prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is get This Payment :\'" + txtAmount.Text + "\' From This Customer :\'" + ddlCustomerName.Text + "(" + ddlCustomerName.SelectedValue + ")\' SuccessFully");
                                prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prmm);
                            }
                        }
                    }
                }
                PaymentId = 0;
            }
        }
        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtAmount.Text.Length <= 20)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void ddlCustomerName_TextChanged(object sender, EventArgs e)
        {
            if (ddlCustomerName.Text!="")
            {
                lblCustomerName.Text = "";
            }
        }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
            if (txtAmount.Text!="")
            {
                lblAmount.Text = "";
            }
        }

        private void ddlCustomerName_Click(object sender, EventArgs e)
        {
            LoadCustomer();
        }

        private void ddlCustomerName_SelectionChangeCommitted(object sender, EventArgs e)
        {
            int amount=0;
            SqlParameter[] prm = new SqlParameter[3];
            prm[0] = new SqlParameter("@Type", 4);
            prm[1] = new SqlParameter("@CustomerId", ddlCustomerName.SelectedValue);
            prm[2] = new SqlParameter("@Status", 1);
            DataTable dt = DataAccess.SpGetData("SpCustomer", prm);
            if (dt.Rows.Count>0)
            {
                prm[0] = new SqlParameter("@Type",4);
                prm[1] = new SqlParameter("@TrainerId", dt.Rows[0]["TrainerId"]);
                prm[2] = new SqlParameter("@Status", 1);
                dt = DataAccess.SpGetData("SpTrainer", prm);
                if (dt.Rows.Count>0)
                {
                    if (""+dt.Rows[0]["TrainerType"]=="Personal")
                    {
                        amount = 500;
                    }
                    prm[0] = new SqlParameter("@Type", 4);
                    prm[1] = new SqlParameter("@CustomerId", ddlCustomerName.SelectedValue);
                    prm[2] = new SqlParameter("@Status", 1);
                    dt = DataAccess.SpGetData("SpMachineUse", prm);
                    if (dt.Rows.Count>0)
                    {
                        amount += dt.Rows.Count * 1000;
                    }
                }
            }
            txtAmount.Text =""+ (amount+1000);
        }
    }
}
