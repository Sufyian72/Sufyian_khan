﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmExpenseHead : Form
    {
        public FrmExpenseHead()
        {
            InitializeComponent();
        }
        int ExpenseHeadId;
        string ExpenseHead;
        public void Edit(string expenseheadid, string expensehead, int Status)
        {
            ExpenseHeadId = Convert.ToInt32(expenseheadid);
            txtExpenseHead.Text = expensehead;
            ExpenseHead = expensehead;
            ddlStatus.Text = Status == 1 ? "Active" : "Inactive";
        }
        private void lblViewExpenseHeadList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmExpenseHeadList obj = new FrmExpenseHeadList();
            obj.ShowDialog();
            this.Close();
        }

        private void lblGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtExpenseHead.Text == "")
            {
                lblExpenseHead.Text = "Required";
                txtExpenseHead.Focus();
            }
            else if (ddlStatus.Text == "")
            {
                lblStatus.Text = "Required";
                ddlStatus.Focus();
            }
            else
            {
                if (ExpenseHeadId > 0)
                {


                    if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                    {
                        SqlParameter[] prm = new SqlParameter[4];
                        prm[0] = new SqlParameter("@Type", 2);
                        prm[1] = new SqlParameter("@ExpenseHeadId", ExpenseHeadId);
                        prm[2] = new SqlParameter("@ExpenseHead", txtExpenseHead.Text);
                        prm[3] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                        if (DataAccess.SpExecuteQuery("SpExpenseHead", prm) == 1)
                        {
                            if (txtExpenseHead.Text != ExpenseHead)
                            {
                                ExpenseHead = txtExpenseHead.Text;
                            }
                            SqlParameter[] prmm = new SqlParameter[4];
                            prmm[0] = new SqlParameter("@Type", 1);
                            prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                            prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Updated This ExpenseHead:\'" + ExpenseHead + "\' Record SuccessFully");
                            prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                            DataAccess.SpExecuteQuery("SpLog", prmm);
                        }
                    }

                }
                else
                {
                    if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                    {
                        SqlParameter[] prm = new SqlParameter[3];
                        prm[0] = new SqlParameter("@Type", 1);
                        prm[1] = new SqlParameter("@ExpenseHead", txtExpenseHead.Text);
                        prm[2] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                        if (DataAccess.SpExecuteQuery("SpExpenseHead", prm) == 1)
                        {
                            SqlParameter[] prmm = new SqlParameter[4];
                            prmm[0] = new SqlParameter("@Type", 1);
                            prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                            prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Inserted This ExpenseHead:\'" + txtExpenseHead.Text + "\' Record SuccessFully");
                            prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                            DataAccess.SpExecuteQuery("SpLog", prmm);
                        }
                    }
                }
                ExpenseHeadId = 0;
            }
        }

        private void txtExpenseHead_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtExpenseHead.Text.Length <= 29)
            {
                if (((e.KeyChar < 'A' || e.KeyChar > 'z') || e.KeyChar == 94 || e.KeyChar == 95 || e.KeyChar == 91 || e.KeyChar == 93 || e.KeyChar == 92) & e.KeyChar != 32 & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtExpenseHead_TextChanged(object sender, EventArgs e)
        {
            if (txtExpenseHead.Text != "")
            {
                lblExpenseHead.Text = "";
            }
        }

        private void ddlStatus_TextChanged(object sender, EventArgs e)
        {
            if (ddlStatus.Text != "")
            {
                lblStatus.Text = "";
            }
        }
    }
}
