﻿
namespace GymManagementSystem
{
    partial class FrmSalary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtSalaryDate = new System.Windows.Forms.DateTimePicker();
            this.lblViewSalaryList = new System.Windows.Forms.LinkLabel();
            this.ddlTrainerName = new System.Windows.Forms.ComboBox();
            this.lblTrainerName = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lblSalaryDate = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblGoToLogin = new System.Windows.Forms.LinkLabel();
            this.lblAmount = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCross = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtSalaryDate
            // 
            this.dtSalaryDate.CustomFormat = "MMMM/yyyy";
            this.dtSalaryDate.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtSalaryDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtSalaryDate.Location = new System.Drawing.Point(280, 209);
            this.dtSalaryDate.Name = "dtSalaryDate";
            this.dtSalaryDate.Size = new System.Drawing.Size(241, 23);
            this.dtSalaryDate.TabIndex = 2;
            // 
            // lblViewSalaryList
            // 
            this.lblViewSalaryList.AutoSize = true;
            this.lblViewSalaryList.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewSalaryList.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.lblViewSalaryList.Location = new System.Drawing.Point(277, 433);
            this.lblViewSalaryList.Name = "lblViewSalaryList";
            this.lblViewSalaryList.Size = new System.Drawing.Size(95, 15);
            this.lblViewSalaryList.TabIndex = 172;
            this.lblViewSalaryList.TabStop = true;
            this.lblViewSalaryList.Text = "View Salary List?";
            this.lblViewSalaryList.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblViewSalaryList_LinkClicked);
            // 
            // ddlTrainerName
            // 
            this.ddlTrainerName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlTrainerName.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddlTrainerName.FormattingEnabled = true;
            this.ddlTrainerName.Location = new System.Drawing.Point(280, 154);
            this.ddlTrainerName.Name = "ddlTrainerName";
            this.ddlTrainerName.Size = new System.Drawing.Size(241, 24);
            this.ddlTrainerName.TabIndex = 1;
            this.ddlTrainerName.SelectionChangeCommitted += new System.EventHandler(this.ddlTrainerName_SelectionChangeCommitted);
            this.ddlTrainerName.TextChanged += new System.EventHandler(this.ddlTrainerName_TextChanged);
            this.ddlTrainerName.Click += new System.EventHandler(this.ddlTrainerName_Click);
            // 
            // lblTrainerName
            // 
            this.lblTrainerName.AutoSize = true;
            this.lblTrainerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrainerName.ForeColor = System.Drawing.Color.Red;
            this.lblTrainerName.Location = new System.Drawing.Point(479, 140);
            this.lblTrainerName.Name = "lblTrainerName";
            this.lblTrainerName.Size = new System.Drawing.Size(0, 12);
            this.lblTrainerName.TabIndex = 169;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.label11.Location = new System.Drawing.Point(277, 136);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 16);
            this.label11.TabIndex = 168;
            this.label11.Text = "Trainer Name";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.panel8.Location = new System.Drawing.Point(280, 177);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(241, 3);
            this.panel8.TabIndex = 170;
            // 
            // lblSalaryDate
            // 
            this.lblSalaryDate.AutoSize = true;
            this.lblSalaryDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalaryDate.ForeColor = System.Drawing.Color.Red;
            this.lblSalaryDate.Location = new System.Drawing.Point(479, 195);
            this.lblSalaryDate.Name = "lblSalaryDate";
            this.lblSalaryDate.Size = new System.Drawing.Size(0, 12);
            this.lblSalaryDate.TabIndex = 166;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.label7.Location = new System.Drawing.Point(277, 190);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 16);
            this.label7.TabIndex = 165;
            this.label7.Text = "Salary Date";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.panel5.Location = new System.Drawing.Point(280, 231);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(241, 3);
            this.panel5.TabIndex = 167;
            // 
            // lblGoToLogin
            // 
            this.lblGoToLogin.AutoSize = true;
            this.lblGoToLogin.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGoToLogin.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.lblGoToLogin.Location = new System.Drawing.Point(722, 433);
            this.lblGoToLogin.Name = "lblGoToLogin";
            this.lblGoToLogin.Size = new System.Drawing.Size(76, 15);
            this.lblGoToLogin.TabIndex = 163;
            this.lblGoToLogin.TabStop = true;
            this.lblGoToLogin.Text = "Go To Login?";
            this.lblGoToLogin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblGoToLogin_LinkClicked);
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmount.ForeColor = System.Drawing.Color.Red;
            this.lblAmount.Location = new System.Drawing.Point(737, 138);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(0, 12);
            this.lblAmount.TabIndex = 162;
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.btnSubmit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.btnSubmit.FlatAppearance.BorderSize = 0;
            this.btnSubmit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmit.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.ForeColor = System.Drawing.Color.White;
            this.btnSubmit.Location = new System.Drawing.Point(409, 270);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(241, 25);
            this.btnSubmit.TabIndex = 4;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(273, 450);
            this.panel1.TabIndex = 160;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(25, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(214, 99);
            this.label3.TabIndex = 11;
            this.label3.Text = "Change Password";
            // 
            // txtAmount
            // 
            this.txtAmount.Enabled = false;
            this.txtAmount.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmount.Location = new System.Drawing.Point(538, 154);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(241, 23);
            this.txtAmount.TabIndex = 3;
            this.txtAmount.TextChanged += new System.EventHandler(this.txtAmount_TextChanged);
            this.txtAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAmount_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.label1.Location = new System.Drawing.Point(535, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 16);
            this.label1.TabIndex = 157;
            this.label1.Text = "Amount";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.panel2.Location = new System.Drawing.Point(538, 176);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(241, 3);
            this.panel2.TabIndex = 164;
            // 
            // btnCross
            // 
            this.btnCross.BackgroundImage = global::GymManagementSystem.Properties.Resources.icons8_close_window_26px;
            this.btnCross.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCross.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCross.FlatAppearance.BorderSize = 0;
            this.btnCross.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCross.Location = new System.Drawing.Point(763, 2);
            this.btnCross.Name = "btnCross";
            this.btnCross.Size = new System.Drawing.Size(33, 35);
            this.btnCross.TabIndex = 174;
            this.btnCross.UseVisualStyleBackColor = true;
            this.btnCross.Click += new System.EventHandler(this.btnCross_Click_1);
            // 
            // FrmSalary
            // 
            this.AcceptButton = this.btnSubmit;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.CancelButton = this.btnCross;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCross);
            this.Controls.Add(this.dtSalaryDate);
            this.Controls.Add(this.lblViewSalaryList);
            this.Controls.Add(this.ddlTrainerName);
            this.Controls.Add(this.lblTrainerName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.lblSalaryDate);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.lblGoToLogin);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmSalary";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmSalary";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtSalaryDate;
        private System.Windows.Forms.LinkLabel lblViewSalaryList;
        private System.Windows.Forms.ComboBox ddlTrainerName;
        private System.Windows.Forms.Label lblTrainerName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lblSalaryDate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.LinkLabel lblGoToLogin;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnCross;
    }
}