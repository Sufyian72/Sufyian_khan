﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmMachineList : Form
    {
        public FrmMachineList()
        {
            InitializeComponent();
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvMachineList.DataSource = DataAccess.SpGetData("SpMachine", prm);
            if (FrmLogin.UserRole == "Operator")
            {
                dgvMachineList.Columns[0].Visible = false;
                dgvMachineList.Columns[1].Visible = false;
            }
        }

       

        private void btnAddMachine_Click(object sender, EventArgs e)
        {
            FrmMachine obj = new FrmMachine();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvMachineList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                {
                    int MachineId = Convert.ToInt32(dgvMachineList.Rows[e.RowIndex].Cells["MachineId"].Value);
                    if (MachineId > 0)
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[2];
                            prm[0] = new SqlParameter("@Type", 3);//for Deletion
                            prm[1] = new SqlParameter("@MachineId", MachineId);
                            if (DataAccess.SpExecuteQuery("SpMachine", prm) == 1)
                            {
                                SqlParameter[] prm1 = new SqlParameter[4];
                                prm1[0] = new SqlParameter("@Type", 1);
                                prm1[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prm1[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Deleted This Machine:\'" + dgvMachineList.Rows[e.RowIndex].Cells["Machine"].Value.ToString() + "\' Record SuccessFully");
                                prm1[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prm1);
                            }
                            SqlParameter[] prmm = new SqlParameter[1];
                            prmm[0] = new SqlParameter("@Type", 4);
                            dgvMachineList.DataSource = DataAccess.SpGetData("SpMachine", prmm);
                        }
                    }
                }
                else if (e.ColumnIndex == 1)
                {
                    FrmMachine obj = new FrmMachine();
                    obj.Edit(dgvMachineList.Rows[e.RowIndex].Cells["MachineId"].Value.ToString(), dgvMachineList.Rows[e.RowIndex].Cells["Machine"].Value.ToString(), dgvMachineList.Rows[e.RowIndex].Cells["Description"].Value.ToString(), Convert.ToInt32(dgvMachineList.Rows[e.RowIndex].Cells["Status"].Value)); obj.ShowDialog();
                    this.Close();
                }
            }
            catch(Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }

        private void txtMachineName_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 5);//Type 8 for searching
            prm[1] = new SqlParameter("@Machine", txtMachineName.Text);
            dgvMachineList.DataSource = DataAccess.SpGetData("SpMachine", prm);
        }
    }
}
