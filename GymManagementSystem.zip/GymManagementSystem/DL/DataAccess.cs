﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymManagementSystem.DL
{
    class DataAccess
    {
        //static SqlConnection con = new SqlConnection("server=SAEEDULLAH\\SQLEXPRESS01;database=DbGymManagementSystem;integrated security=true");
        public static void ExecuteQuery(string Query)
        {
            SqlConnection con = new SqlConnection("server=SAEEDULLAH\\SQLEXPRESS01;database=DbGymManagementSystem;integrated security=true");
            SqlCommand cmd = new SqlCommand(Query, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static void ExecuteQuery(string Query, SqlParameter[] prm)
        {
            SqlConnection con = new SqlConnection("server=SAEEDULLAH\\SQLEXPRESS01;database=DbGymManagementSystem;integrated security=true");
            SqlCommand cmd = new SqlCommand(Query, con);
            cmd.Parameters.AddRange(prm);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static int SpExecuteQuery(string ProcedureName, SqlParameter[] prm)
        {
            SqlConnection con = new SqlConnection("server=SAEEDULLAH\\SQLEXPRESS01;database=DbGymManagementSystem;integrated security=true");
            SqlCommand cmd = new SqlCommand(ProcedureName, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddRange(prm);
            con.Open();
            int submit = cmd.ExecuteNonQuery();
            con.Close();
            return submit;
        }
        public static DataTable GetData(string Query)
        {
            SqlConnection con = new SqlConnection("server=SAEEDULLAH\\SQLEXPRESS01;database=DbGymManagementSystem;integrated security=true");
            SqlDataAdapter da = new SqlDataAdapter(Query, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
        public static DataTable GetData(string Query, SqlParameter[] prm)
        {
            SqlConnection con = new SqlConnection("server=SAEEDULLAH\\SQLEXPRESS01;database=DbGymManagementSystem;integrated security=true");
            SqlCommand cmd = new SqlCommand(Query, con);
            cmd.Parameters.AddRange(prm);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
        public static DataTable SpGetData(string ProcedureName, SqlParameter[] prm)
        {
            SqlConnection con = new SqlConnection("server=SAEEDULLAH\\SQLEXPRESS01;database=DbGymManagementSystem;integrated security=true");
            SqlCommand cmd = new SqlCommand(ProcedureName, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddRange(prm);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }
}
