﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmPaymentList : Form
    {
        public FrmPaymentList()
        {
            InitializeComponent();
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvPaymentList.DataSource = DataAccess.SpGetData("SpPayment", prm);
            if (FrmLogin.UserRole == "Operator")
            {
                dgvPaymentList.Columns[0].Visible = false;
                dgvPaymentList.Columns[1].Visible = false;
            }
        }
      
        private void btnAddPayment_Click(object sender, EventArgs e)
        {
            FrmPayment obj = new FrmPayment();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvPaymentList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                {
                    int PaymentId = Convert.ToInt32(dgvPaymentList.Rows[e.RowIndex].Cells["PaymentId"].Value);
                    if (PaymentId > 0)
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[2];
                            prm[0] = new SqlParameter("@Type", 3);//for Deletion
                            prm[1] = new SqlParameter("@PaymentId", PaymentId);
                            if (DataAccess.SpExecuteQuery("SpPayment", prm) == 1)
                            {
                                SqlParameter[] prm1 = new SqlParameter[4];
                                prm1[0] = new SqlParameter("@Type", 1);
                                prm1[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prm1[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Deleted This Customer :\'" + dgvPaymentList.Rows[e.RowIndex].Cells["CustomerName"].Value.ToString() + "\'(" + dgvPaymentList.Rows[e.RowIndex].Cells["CustomerId"].Value + ") " + "Payment :\'" + dgvPaymentList.Rows[e.RowIndex].Cells["Amount"].Value + "\' Record SuccessFully");
                                prm1[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prm1);
                            }
                            SqlParameter[] prmm = new SqlParameter[1];
                            prmm[0] = new SqlParameter("@Type", 4);
                            dgvPaymentList.DataSource = DataAccess.SpGetData("SpPayment", prmm);
                        }
                    }
                }
                else if (e.ColumnIndex == 1)
                {

                    FrmPayment obj = new FrmPayment();
                    if (CheckCustomer == 1)
                    {
                        obj.Edit("0", dgvPaymentList.Rows[e.RowIndex].Cells["CustomerId"].Value.ToString(), 0, DateTime.Now.ToString());
                    }
                    else
                    {
                        obj.Edit(dgvPaymentList.Rows[e.RowIndex].Cells["PaymentId"].Value.ToString(), dgvPaymentList.Rows[e.RowIndex].Cells["CustomerId"].Value.ToString(), Convert.ToInt32(dgvPaymentList.Rows[e.RowIndex].Cells["Amount"].Value), dgvPaymentList.Rows[e.RowIndex].Cells["PaymentDate"].Value.ToString());
                    }
                    obj.ShowDialog();
                    this.Close();
                    CheckCustomer = 0;
                }
                CheckCustomer = 0;
            }
            catch
            {

            }
        }
        int CheckCustomer = 0;
        private void dtSearchDefaulterCustomer_ValueChanged(object sender, EventArgs e)
        {
            CheckCustomer = 1;
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 4);//Type 4 for searching
            prm[1] = new SqlParameter("@PaymentDate", dtSearchDefaulterCustomer.Value.ToString("Y"));
            DataTable dt = DataAccess.SpGetData("SpPayment", prm);
            if (dt.Rows.Count > 0)
            {
                //FrmTrainerPendingSalary obj = new FrmTrainerPendingSalary();
                //obj.TrainersPendingSalary(dt);
                //obj.ShowDialog();
                //this.Close();
                string Query;
                int Length = dt.Rows.Count;
                if (Length > 1)
                {
                    //select *from Tbl where 
                    Query = "select *from TblCustomer where   ";
                    int i;
                    for (i = 0; i < Length - 1; i++)
                    {
                        Query += " CustomerId<>" + dt.Rows[i]["CustomerId"] + " and ";
                    }
                    if (i + 1 == Length)
                    {
                        Query += " CustomerId<>" + dt.Rows[i]["CustomerId"];
                    }
                }
                else
                {
                    Query = "select *from TblCustomer where CustomerId<>" + dt.Rows[0]["CustomerId"];
                }
                dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(Query, "data source=SAEEDULLAH\\SQLEXPRESS01;initial catalog=DbGymManagementSystem;integrated security=true");
                da.Fill(dt);
                dgvPaymentList.DataSource = dt;
            }
        }

        private void dtPaymentDate_ValueChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 4);//Type 8 for searching
            prm[1] = new SqlParameter("@PaymentDate", dtPaymentDate.Value.ToString("Y"));
            dgvPaymentList.DataSource = DataAccess.SpGetData("SpPayment", prm);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvPaymentList.DataSource = DataAccess.SpGetData("SpPayment", prm);
        }
    }
}
