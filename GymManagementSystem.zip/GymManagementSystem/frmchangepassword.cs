﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmChangePassword : Form
    {
        public FrmChangePassword()
        {
            InitializeComponent();
        }

        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            if (txtUserNameEmailContact.Text == "")
            {
                lblUserNameEmailContact.Text = "Required";
                txtUserNameEmailContact.Focus();
            }
            else if (txtPassword.Text == "")
            {
                lblPassword.Text = "Required";
                txtPassword.Focus();
            }
            else if (txtNewPassword.Text == "")
            {
                lblNewPassword.Text = "Required";
                txtNewPassword.Focus();
            }
            else if (txtConfirmPassword.Text == "")
            {
                lblConfirmPassword.Text = "Required";
                txtConfirmPassword.Focus();
            }
            else
            {
                if (txtNewPassword.Text == txtConfirmPassword.Text)
                {
                    SqlParameter[] prm = new SqlParameter[4];
                    prm[0] = new SqlParameter("@Type", 7);//For Login
                    prm[1] = new SqlParameter("@UserName", txtUserNameEmailContact.Text);
                    prm[2] = new SqlParameter("@Email", txtUserNameEmailContact.Text);
                    prm[3] = new SqlParameter("@Contact", txtUserNameEmailContact.Text);
                    DataTable dt = DataAccess.SpGetData("SpUser", prm);
                    if (dt.Rows.Count > 0)
                    {
                        SqlParameter[] prmm = new SqlParameter[5];
                        prmm[0] = new SqlParameter("@Type", 10);//For Login
                        prmm[1] = new SqlParameter("@UserName", txtUserNameEmailContact.Text);
                        prmm[2] = new SqlParameter("@Email", txtUserNameEmailContact.Text);
                        prmm[3] = new SqlParameter("@Contact", txtUserNameEmailContact.Text);
                        prmm[4] = new SqlParameter("@Password", txtPassword.Text);
                        dt = DataAccess.SpGetData("SpUser", prmm);
                        if (dt.Rows.Count > 0)
                        {
                            prmm[0] = new SqlParameter("@Type", 6);
                            prmm[1] = new SqlParameter("@UserName", txtUserNameEmailContact.Text);
                            prmm[2] = new SqlParameter("@Email", txtUserNameEmailContact.Text);
                            prmm[3] = new SqlParameter("@Contact", txtUserNameEmailContact.Text);
                            prmm[4] = new SqlParameter("@Password", txtConfirmPassword.Text);
                            if (DataAccess.SpExecuteQuery("SpUser", prmm) == 1)
                            {
                                SqlParameter[] prm1 = new SqlParameter[4];
                                prm1[0] = new SqlParameter("@Type", 1);
                                prm1[1] = new SqlParameter("@UserId",Convert.ToInt32( dt.Rows[0]["UserId"]));
                                prm1[2] = new SqlParameter("@Log", "This User:\'" + txtUserNameEmailContact.Text + "\'  Changed  Password SuccessFully");
                                prm1[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prm1);
                                MessageBox.Show("Password Changed SuccessFully");
                            }

                        }
                        else
                        {
                            MessageBox.Show("Incorrect Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Incorrect UserName or Contact or Email", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("New Password and Confirm Password are not same", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtUserNameEmailContact_TextChanged(object sender, EventArgs e)
        {
            if (txtUserNameEmailContact.Text != "")
            {
                lblUserNameEmailContact.Text = "";
            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtPassword.Text != "")
            {
                lblPassword.Text = "";
            }
        }

        private void txtNewPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtNewPassword.Text != "")
            {
                lblNewPassword.Text = "";
            }
        }

        private void txtConfirmPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtConfirmPassword.Text != "")
            {
                lblConfirmPassword.Text = "";
            }
        }
    }
}
