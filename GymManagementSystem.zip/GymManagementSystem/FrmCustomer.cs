﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmCustomer : Form
    {
        public FrmCustomer()
        {
            InitializeComponent();
            LoadTrainer();
        }
        string CustomerName;
        int CustomerId;
        public void Edit(string customerid, string customername, string contact, string cnic, string weight, string gender, string trainerid, string address, int age, int Status)
        {
            CustomerId = Convert.ToInt32(customerid);
            txtName.Text = customername;
            CustomerName = customername;
            txtContact.Text = contact;
            txtCnic.Text = cnic;
            ddlGender.Text = gender;
            txtAddress.Text = address;
            txtWeight.Text = weight;
            txtAge.Text = "" + age;
            ddlStatus.Text = Status == 1 ? "Active" : "Inactive";
            ddlTrainerName.SelectedValue =Convert.ToInt32( trainerid);
        }
        public void LoadTrainer()
        {
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            DataTable dt = DataAccess.SpGetData("SpTrainer", prm);
            ddlTrainerName.DataSource = dt;
            ddlTrainerName.DisplayMember = "TrainerName";
            ddlTrainerName.ValueMember = "TrainerId";
        }
        private void lblViewCustomerList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmCustomerList obj = new FrmCustomerList();
            obj.ShowDialog();
            this.Close();
        }

        private void lblGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                lblName.Text = "Required";
                txtName.Focus();
            }
            else if (txtContact.Text == "")
            {
                lblContact.Text = "Required";
                txtContact.Focus();
            }
            else if (txtCnic.Text == "")
            {
                lblCnic.Text = "Required";
                txtCnic.Focus();
            }
            else if (txtWeight.Text == "")
            {
                lblWeight.Text = "Required";
                txtWeight.Focus();
            }
            else if (ddlGender.Text == "")
            {
                lblGender.Text = "Required";
                ddlGender.Focus();
            }
            else if (ddlTrainerName.Text == "")
            {
                lblTrainerName.Text = "Required";
                ddlTrainerName.Focus();
            }
            else if (txtAddress.Text == "")
            {
                lblAddress.Text = "Required";
                txtAddress.Focus();
            }
            else if (txtAge.Text == "")
            {
                lblAge.Text = "Required";
                txtAge.Focus();
            }
            else if (ddlStatus.Text == "")
            {
                lblStatus.Text = "Required";
                ddlStatus.Focus();
            }
            else
            {
                if (CustomerId > 0)
                {

                    if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                    {
                        SqlParameter[] prm = new SqlParameter[12];
                        prm[0] = new SqlParameter("@Type", 2);
                        prm[1] = new SqlParameter("@CustomerId", CustomerId);
                        prm[2] = new SqlParameter("@CustomerName", txtName.Text);
                        prm[3] = new SqlParameter("@CustomerContact", txtContact.Text);
                        prm[4] = new SqlParameter("@CustomerCnic", txtCnic.Text);
                        prm[5] = new SqlParameter("@CustomerAddress", txtAddress.Text);
                        prm[6] = new SqlParameter("@CustomerGender", ddlGender.Text);
                        prm[7] = new SqlParameter("@CustomerAge", txtAge.Text);
                        prm[8] = new SqlParameter("@CustomerWeight", txtWeight.Text);
                        prm[9] = new SqlParameter("@IsDeleted", 0);
                        prm[10] = new SqlParameter("@TrainerId", ddlTrainerName.SelectedValue);
                        prm[11] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                        if (DataAccess.SpExecuteQuery("SpCustomer", prm) == 1)
                        {
                            if (txtName.Text != CustomerName)
                            {
                                CustomerName = txtName.Text;
                            }
                            SqlParameter[] prmm = new SqlParameter[4];
                            prmm[0] = new SqlParameter("@Type", 1);
                            prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                            prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Updated This Customer:\'" + txtName.Text + "\' Record SuccessFully");
                            prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                            DataAccess.SpExecuteQuery("SpLog", prmm);
                        }
                    }
                }
                else
                {
                    if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                    {
                        SqlParameter[] prm = new SqlParameter[11];
                        prm[0] = new SqlParameter("@Type", 1);
                        prm[1] = new SqlParameter("@CustomerName", txtName.Text);
                        prm[2] = new SqlParameter("@CustomerContact", txtContact.Text);
                        prm[3] = new SqlParameter("@CustomerCnic", txtCnic.Text);
                        prm[4] = new SqlParameter("@CustomerAddress", txtAddress.Text);
                        prm[5] = new SqlParameter("@CustomerGender", ddlGender.Text);
                        prm[6] = new SqlParameter("@CustomerAge", txtAge.Text);
                        prm[7] = new SqlParameter("@CustomerWeight", txtWeight.Text);
                        prm[8] = new SqlParameter("@IsDeleted", 0);
                        prm[9] = new SqlParameter("@TrainerId", ddlTrainerName.SelectedValue);
                        prm[10] = new SqlParameter("@Status", ddlStatus.Text == "Active" ? 1 : 0);
                        if (DataAccess.SpExecuteQuery("SpCustomer", prm) == 1)
                        {
                            SqlParameter[] prmm = new SqlParameter[4];
                            prmm[0] = new SqlParameter("@Type", 1);
                            prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                            prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Inserted This Customer:\'" + txtName.Text + "\' Record SuccessFully");
                            prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                            if(DataAccess.SpExecuteQuery("SpLog", prmm)==1)
                            {
                                FrmMachineUse obj = new FrmMachineUse();
                                obj.ShowDialog();
                                this.Close();
                            }
                        }
                    }

                }
                CustomerId = 0;
            }
        }

        private void btnCross_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtName.Text.Length <= 29)
            {
                if (((e.KeyChar < 'A' || e.KeyChar > 'z') || e.KeyChar == 94 || e.KeyChar == 95 || e.KeyChar == 91 || e.KeyChar == 93 || e.KeyChar == 92) & e.KeyChar != 32 & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtContact_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtContact.Text.Length <= 10)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtCnic_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtCnic.Text.Length <= 12)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtWeight_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtWeight.Text.Length <= 2)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtAge.Text.Length <= 2)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            if (txtName.Text != "")
            {
                lblName.Text = "";
            }
        }

        private void txtContact_TextChanged(object sender, EventArgs e)
        {
            if (txtContact.Text != "")
            {
                lblContact.Text = "";
            }
        }

        private void txtCnic_TextChanged(object sender, EventArgs e)
        {
            if (txtCnic.Text != "")
            {
                lblCnic.Text = "";
            }
        }

        private void txtWeight_TextChanged(object sender, EventArgs e)
        {
            if (txtWeight.Text != "")
            {
                lblWeight.Text = "";
            }
        }

        private void ddlGender_TextChanged(object sender, EventArgs e)
        {
            if (ddlGender.Text != "")
            {
                lblGender.Text = "";
            }
        }

        private void ddlTrainerName_TextChanged(object sender, EventArgs e)
        {
            if (ddlTrainerName.Text != "")
            {
                lblTrainerName.Text = "";
            }
        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {
            if (txtAddress.Text != "")
            {
                lblAddress.Text = "";
            }
        }

        private void txtAge_TextChanged(object sender, EventArgs e)
        {
            if (txtAge.Text != "")
            {
                lblAge.Text = "";
            }
        }

        private void ddlStatus_TextChanged(object sender, EventArgs e)
        {
            if (ddlStatus.Text != "")
            {
                lblStatus.Text = "";
            }
        }
    }
}
