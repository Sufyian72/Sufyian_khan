﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmUserRegistration : Form
    {
        public FrmUserRegistration()
        {
            InitializeComponent();
        }
        int id;
        public void Edit(int ID)
        {
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@UserId", ID);
            string Query = "select *from TblUser Where UserId=@UserId";
            DataTable dt = DataAccess.GetData(Query, prm);
            if (dt.Rows.Count > 0)
            {
                id = Convert.ToInt32(dt.Rows[0]["UserID"]);
                txtfirstname.Text = "" + dt.Rows[0]["FirstName"];
                txtlastname.Text = "" + dt.Rows[0]["LastName"];
                txtusername.Text = "" + dt.Rows[0]["UserName"];
                txtemail.Text = "" + dt.Rows[0]["Email"];
                txtcontact.Text = "" + dt.Rows[0]["Contact"];
                txtcnic.Text = "" + dt.Rows[0]["Cnic"];

                cmbstatus.Text = Convert.ToInt32(dt.Rows[0]["Status"]) == 1 ? "Active" : "Inactive";
                cmbrole.Text = "" + dt.Rows[0]["UserRole"];
                txtpassword.Text = "" + dt.Rows[0]["Password"];
                txtconformpassword.Text = "" + dt.Rows[0]["Password"];
                txtage.Text = "" + dt.Rows[0]["Age"];
                string gender = "" + dt.Rows[0]["Gender"];
                if (gender == "Male")
                {
                    rdomale.Checked = true;
                }
                else if (gender == "Female")
                {
                    rdofemale.Checked = true;
                }
                else if (gender == "Other")
                {
                    rdoother.Checked = true;
                }
                txtaddress.Text = "" + dt.Rows[0]["Address"];
                btnRegister.Text = "Upate Data";
            }
        }
        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (txtfirstname.Text == "First Name" || txtfirstname.Text == "")
            {
                lblFirstName.Text = "Enter FirstName";
                //txtfirstname.BackColor = Color.White;
                //txtfirstname.ForeColor = Color.Black;
                //txtfirstname.Text = "Enter First Name";
            }
            else if (txtlastname.Text=="LastName"||txtlastname.Text=="")
            {
                lbllastname.Text = "Enter LastName";
            }
            else if (true)
            {

            }
            else if (true)
            {

            }
            else if (true)
            {

            }
            else if (true)
            {

            }
            else if (true)
            {

            }
            else if (true)
            {

            }
            else if (true)
            {

            }
            else if (true)
            {

            }
            else if (true)
            {

            }
            else if (true)
            {

            }
            else if (true)
            {

            }
            else
            {
                if (txtpassword.Text == txtconformpassword.Text)
                {
                    if (txtemail.Text.Contains("@gmail.com") == false)
                    {
                        MessageBox.Show("Must use: @gmail.com  in your email");
                    }
                    else if (txtemail.Text == "@gmail.com")
                    {
                        MessageBox.Show("Use:example@gmail.com");
                    }
                    else
                    {
                        SqlParameter[] prm = new SqlParameter[3];
                        prm[0] = new SqlParameter("@UserName", txtusername.Text);
                        prm[1] = new SqlParameter("@Contact", txtcontact.Text);
                        prm[2] = new SqlParameter("@Email", txtemail.Text);
                        string Query;
                        if (id > 0)
                        {
                            Query = "select *from TblUser where (UserName=@UserName or Email=@Email or Contact=@Contact) and UserId<>" + id;
                            if (DataAccess.GetData(Query, prm).Rows.Count > 0)
                            {
                                MessageBox.Show("This User is Already Exist");
                            }
                            else
                            {

                                prm = new SqlParameter[14];
                                prm[0] = new SqlParameter("@UserID", id);
                                prm[1] = new SqlParameter("@FirstName", txtfirstname.Text);
                                prm[2] = new SqlParameter("@LastName", txtlastname.Text);
                                prm[3] = new SqlParameter("@UserName", txtusername.Text);
                                prm[4] = new SqlParameter("@Email", txtemail.Text);
                                prm[5] = new SqlParameter("@Contact", txtcontact.Text);
                                prm[6] = new SqlParameter("@CNIC", txtcnic.Text);
                                string gender = "";
                                if (rdomale.Checked == true)
                                {
                                    gender = rdomale.Text;
                                }
                                else if (rdofemale.Checked == true)
                                {
                                    gender = rdofemale.Text;
                                }
                                else if (rdoother.Checked == true)
                                {
                                    gender = rdoother.Text;
                                }
                                prm[7] = new SqlParameter("@Gender", gender);
                                prm[8] = new SqlParameter("@Address", txtaddress.Text);
                                prm[9] = new SqlParameter("@Age", txtage.Text);
                                //int status;
                                //if (cmbstatus.Text=="Active")
                                //{
                                //    status = 1;
                                //}
                                //else
                                //{
                                //    status = 0;
                                //}
                                //prm[10] = new SqlParameter("@Status", status);
                                prm[10] = new SqlParameter("@Status", cmbstatus.Text == "Active" ? 1 : 0);
                                prm[11] = new SqlParameter("@UserRole", cmbrole.Text);
                                prm[12] = new SqlParameter("@OTP", "null");
                                prm[13] = new SqlParameter("@Password", txtpassword.Text);


                                Query = "update TblUser set FirstName=@FirstName,LastName=@LastName,UserName=@UserName,Email=@Email,Contact=@Contact,CNIC=@CNIC,Gender=@Gender,Address=@Address,Age=@Age,Status=@Status,UserRole=@UserRole,OTP=@OTP,Password=@Password where UserId=" + id;

                                DialogResult d = MessageBox.Show("Are you Sure!", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                                if (d == DialogResult.Yes)
                                {
                                    DataAccess.ExecuteQuery(Query, prm);
                                    MessageBox.Show("SuccessFully Submitted");
                                    btnRegister.Text = "Register";
                                    id = 0;
                                }
                            }
                        }
                        else if (id == 0)
                        {


                            Query = "select *from TblUser where UserName=@UserName or Email=@Email or Contact=@Contact";
                            if (DataAccess.GetData(Query, prm).Rows.Count > 0)
                            {
                                MessageBox.Show("This User is Already Exist");
                            }
                            else
                            {

                                prm = new SqlParameter[14];
                                prm[0] = new SqlParameter("@UserID", id);
                                prm[1] = new SqlParameter("@FirstName", txtfirstname.Text);
                                prm[2] = new SqlParameter("@LastName", txtlastname.Text);
                                prm[3] = new SqlParameter("@UserName", txtusername.Text);
                                prm[4] = new SqlParameter("@Email", txtemail.Text);
                                prm[5] = new SqlParameter("@Contact", txtcontact.Text);
                                prm[6] = new SqlParameter("@CNIC", txtcnic.Text);
                                string gender = "";
                                if (rdomale.Checked == true)
                                {
                                    gender = rdomale.Text;
                                }
                                else if (rdofemale.Checked == true)
                                {
                                    gender = rdofemale.Text;
                                }
                                else if (rdoother.Checked == true)
                                {
                                    gender = rdoother.Text;
                                }
                                prm[7] = new SqlParameter("@Gender", gender);
                                prm[8] = new SqlParameter("@Address", txtaddress.Text);
                                prm[9] = new SqlParameter("@Age", txtage.Text);
                                //int status;
                                //if (cmbstatus.Text=="Active")
                                //{
                                //    status = 1;
                                //}
                                //else
                                //{
                                //    status = 0;
                                //}
                                //prm[10] = new SqlParameter("@Status", status);
                                prm[10] = new SqlParameter("@Status", cmbstatus.Text == "Active" ? 1 : 0);
                                prm[11] = new SqlParameter("@UserRole", cmbrole.Text);
                                prm[12] = new SqlParameter("@OTP", "null");
                                prm[13] = new SqlParameter("@Password", txtpassword.Text);
                                Query = "insert into TblUser values(@FirstName,@LastName,@UserName,@Email,@Contact,@CNIC,@Gender,@Address,@Age,@Status,@UserRole,@OTP,@Password)";
                                DialogResult d = MessageBox.Show("Are you Sure!", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                                if (d == DialogResult.Yes)
                                {
                                    DataAccess.ExecuteQuery(Query, prm);
                                    MessageBox.Show("SuccessFully Submitted");
                                    btnRegister.Text = "Register";
                                    id = 0;
                                }
                            }
                        }
                        //DataTable dt= DataAccess.GetData(Query, prm);


                    }
                }
                else
                {
                    MessageBox.Show("Password and confirm password are not same", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtpassword_TextChanged(object sender, EventArgs e)
        {
            txtconformpassword.Text = txtpassword.Text;
        }

        private void rdomale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtfirstname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 'A' || e.KeyChar > 'z') & e.KeyChar != 8 & e.KeyChar != 32)
            {
                e.Handled = true;
            }
        }

        private void txtlastname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 'A' || e.KeyChar > 'z') & e.KeyChar != 8 & e.KeyChar != 32)
            {
                e.Handled = true;
            }
        }

        private void txtusername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 'a' || e.KeyChar > 'z') & e.KeyChar != '_' & e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void txtemail_KeyPress(object sender, KeyPressEventArgs e)
       {
            if ((e.KeyChar < 'a' || e.KeyChar > 'z') & e.KeyChar != '@' & e.KeyChar != '.' & e.KeyChar != 8 & e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void txtcnic_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtcnic.Text.Length < 15)
            {

                if ((e.KeyChar < '0' || e.KeyChar > '9') & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtage.Text.Length < 3)
            {

                if ((e.KeyChar < '0' || e.KeyChar > '9') & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void txtcontact_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtcontact.Text.Length < 11)
            {

                if ((e.KeyChar < '0' || e.KeyChar > '9') & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }

            }
        }

        private void txtfirstname_Click(object sender, EventArgs e)
        {
            txtfirstname.Text = "";
            txtfirstname.BackColor = Color.White;
            txtfirstname.ForeColor = Color.Black;
        }

        private void txtfirstname_TextChanged(object sender, EventArgs e)
        {
            if (txtfirstname.Text != "Enter First Name" & txtfirstname.Text != "")
            {
                lblFirstName.Text = "";
            }
        }

        private void btnViewUserList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmlistUserRegistration obj = new frmlistUserRegistration();
            this.Hide();
            obj.ShowDialog();
        }

        private void txtemail_TextChanged(object sender, EventArgs e)
        {

        }



        //private void txtpassword_TextChanged(object sender, EventArgs e)

    }
}
