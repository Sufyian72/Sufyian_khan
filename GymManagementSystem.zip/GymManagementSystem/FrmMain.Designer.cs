﻿
namespace GymManagementSystem
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trainerListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salaryListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expenseListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expenseHeadListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMachineList = new System.Windows.Forms.ToolStripMenuItem();
            this.UserListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutUsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.machineUseListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.menuStrip1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem,
            this.pagesToolStripMenuItem,
            this.aboutUsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1273, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.homeToolStripMenuItem.Text = "Home";
            // 
            // pagesToolStripMenuItem
            // 
            this.pagesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customerListToolStripMenuItem,
            this.trainerListToolStripMenuItem,
            this.paymentListToolStripMenuItem,
            this.salaryListToolStripMenuItem,
            this.expenseListToolStripMenuItem,
            this.expenseHeadListToolStripMenuItem,
            this.toolStripMachineList,
            this.UserListToolStripMenuItem,
            this.logListToolStripMenuItem,
            this.machineUseListToolStripMenuItem});
            this.pagesToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.pagesToolStripMenuItem.Name = "pagesToolStripMenuItem";
            this.pagesToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.pagesToolStripMenuItem.Text = "Pages";
            // 
            // customerListToolStripMenuItem
            // 
            this.customerListToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.customerListToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.customerListToolStripMenuItem.Name = "customerListToolStripMenuItem";
            this.customerListToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.customerListToolStripMenuItem.Text = "Customer List";
            this.customerListToolStripMenuItem.Click += new System.EventHandler(this.customerListToolStripMenuItem_Click);
            // 
            // trainerListToolStripMenuItem
            // 
            this.trainerListToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.trainerListToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.trainerListToolStripMenuItem.Name = "trainerListToolStripMenuItem";
            this.trainerListToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.trainerListToolStripMenuItem.Text = "Trainer List";
            this.trainerListToolStripMenuItem.Click += new System.EventHandler(this.trainerListToolStripMenuItem_Click);
            // 
            // paymentListToolStripMenuItem
            // 
            this.paymentListToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.paymentListToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.paymentListToolStripMenuItem.Name = "paymentListToolStripMenuItem";
            this.paymentListToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.paymentListToolStripMenuItem.Text = "Payment List";
            this.paymentListToolStripMenuItem.Click += new System.EventHandler(this.paymentListToolStripMenuItem_Click);
            // 
            // salaryListToolStripMenuItem
            // 
            this.salaryListToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.salaryListToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.salaryListToolStripMenuItem.Name = "salaryListToolStripMenuItem";
            this.salaryListToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.salaryListToolStripMenuItem.Text = "Salary List";
            this.salaryListToolStripMenuItem.Click += new System.EventHandler(this.salaryListToolStripMenuItem_Click);
            // 
            // expenseListToolStripMenuItem
            // 
            this.expenseListToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.expenseListToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.expenseListToolStripMenuItem.Name = "expenseListToolStripMenuItem";
            this.expenseListToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.expenseListToolStripMenuItem.Text = "Expense List";
            this.expenseListToolStripMenuItem.Click += new System.EventHandler(this.expenseListToolStripMenuItem_Click);
            // 
            // expenseHeadListToolStripMenuItem
            // 
            this.expenseHeadListToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.expenseHeadListToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.expenseHeadListToolStripMenuItem.Name = "expenseHeadListToolStripMenuItem";
            this.expenseHeadListToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.expenseHeadListToolStripMenuItem.Text = "Expense Head List";
            this.expenseHeadListToolStripMenuItem.Click += new System.EventHandler(this.expenseHeadListToolStripMenuItem_Click);
            // 
            // toolStripMachineList
            // 
            this.toolStripMachineList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.toolStripMachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.toolStripMachineList.Name = "toolStripMachineList";
            this.toolStripMachineList.Size = new System.Drawing.Size(192, 22);
            this.toolStripMachineList.Text = "Machine List";
            this.toolStripMachineList.Click += new System.EventHandler(this.toolStripMachineList_Click);
            // 
            // UserListToolStripMenuItem
            // 
            this.UserListToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.UserListToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.UserListToolStripMenuItem.Name = "UserListToolStripMenuItem";
            this.UserListToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.UserListToolStripMenuItem.Text = "UserList";
            this.UserListToolStripMenuItem.Click += new System.EventHandler(this.UserListToolStripMenuItem_Click);
            // 
            // logListToolStripMenuItem
            // 
            this.logListToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.logListToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.logListToolStripMenuItem.Name = "logListToolStripMenuItem";
            this.logListToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.logListToolStripMenuItem.Text = "LogList";
            this.logListToolStripMenuItem.Click += new System.EventHandler(this.logListToolStripMenuItem_Click);
            // 
            // aboutUsToolStripMenuItem
            // 
            this.aboutUsToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.aboutUsToolStripMenuItem.Name = "aboutUsToolStripMenuItem";
            this.aboutUsToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.aboutUsToolStripMenuItem.Text = "About Us";
            this.aboutUsToolStripMenuItem.Click += new System.EventHandler(this.aboutUsToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.panel1.Location = new System.Drawing.Point(915, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(358, 24);
            this.panel1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(1105, 24);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(168, 490);
            this.panel2.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(32)))));
            this.panel3.Location = new System.Drawing.Point(107, 447);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 67);
            this.panel3.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(27)))), ((int)(((byte)(32)))));
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.label1.Location = new System.Drawing.Point(469, 479);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 26);
            this.label1.TabIndex = 5;
            this.label1.Text = "Developed By Netrex Team";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::GymManagementSystem.Properties.Resources.SharedScreenshot3;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1273, 490);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // machineUseListToolStripMenuItem
            // 
            this.machineUseListToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(31)))), ((int)(((byte)(32)))));
            this.machineUseListToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(61)))), ((int)(((byte)(12)))));
            this.machineUseListToolStripMenuItem.Name = "machineUseListToolStripMenuItem";
            this.machineUseListToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.machineUseListToolStripMenuItem.Text = "MachineUseList";
            this.machineUseListToolStripMenuItem.Click += new System.EventHandler(this.machineUseListToolStripMenuItem_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1273, 514);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmMain";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pagesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trainerListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salaryListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expenseListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expenseHeadListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem UserListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutUsToolStripMenuItem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMachineList;
        private System.Windows.Forms.ToolStripMenuItem logListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem machineUseListToolStripMenuItem;
    }
}