﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmSalary : Form
    {
        public FrmSalary()
        {
            InitializeComponent();
        }
        int SalaryId, Amount;
        public void LoadTrainer()
        {
            DataTable dt = DataAccess.GetData("select *from TblTrainer");
            ddlTrainerName.DataSource = dt;
            ddlTrainerName.DisplayMember = "TrainerName";
            ddlTrainerName.ValueMember = "TrainerId";
        }
        public void Edit(string salaryid, string trainername, int amount, string salarydate)
        {
            LoadTrainer();
            SalaryId = Convert.ToInt32(salaryid);
            ddlTrainerName.SelectedValue =Convert.ToInt32( trainername) ;
            txtAmount.Text = "" + amount;
            Amount = amount;
            dtSalaryDate.Value =Convert.ToDateTime(salarydate);
            txtAmount.Enabled = true;
        }
        private void lblViewSalaryList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmSalaryList obj = new FrmSalaryList();
            obj.ShowDialog();
            this.Close();
        }

        private void lblGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (ddlTrainerName.Text == "")
            {
                lblTrainerName.Text = "Required";
                ddlTrainerName.Focus();
            }
            else if (txtAmount.Text == "")
            {
                lblAmount.Text = "Required";
                txtAmount.Focus();
            }
            else
            {
                if (SalaryId > 0)
                {


                    if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                    {
                        SqlParameter[] prm = new SqlParameter[5];
                        prm[0] = new SqlParameter("@Type", 2);
                        prm[1] = new SqlParameter("@SalaryId", SalaryId);
                        prm[2] = new SqlParameter("@TrainerId", ddlTrainerName.SelectedValue);
                        prm[3] = new SqlParameter("@Amount", txtAmount.Text);
                        prm[4] = new SqlParameter("@SalaryDate", dtSalaryDate.Value.ToString("Y"));
                        if (DataAccess.SpExecuteQuery("SpSalary", prm) == 1)
                        {
                            SqlParameter[] prmm = new SqlParameter[4];
                            prmm[0] = new SqlParameter("@Type", 1);
                            prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                            if (txtAmount.Text != "" + Amount)
                            {
                                prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Updated This Trainer :\'" + ddlTrainerName.Text +"("+ddlTrainerName.SelectedValue+")\' Salary From This :\'" + Amount + "\' To This :\'" + txtAmount.Text + "\' SuccessFully");
                            }
                            else
                            {
                                prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Updated This Trainer :\'" + ddlTrainerName.Text + "(" + ddlTrainerName.SelectedValue + ")\' Salary Record SuccessFully");
                            }
                            prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                            DataAccess.SpExecuteQuery("SpLog", prmm);
                        }
                    }
                    txtAmount.Enabled = false;
                }
                else
                {
                    SqlParameter[] parameters = new SqlParameter[3];
                    parameters[0] = new SqlParameter("@Type", 4);
                    parameters[1] = new SqlParameter("@TrainerId", ddlTrainerName.SelectedValue);
                    parameters[2] = new SqlParameter("@SalaryDate", dtSalaryDate.Value.ToString("Y"));
                    DataTable dt = DataAccess.SpGetData("SpSalary", parameters);
                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("Already Paid for this Month");
                    }
                    else
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[4];
                            prm[0] = new SqlParameter("@Type", 1);
                            prm[1] = new SqlParameter("@TrainerId", ddlTrainerName.SelectedValue);
                            prm[2] = new SqlParameter("@Amount", txtAmount.Text);
                            prm[3] = new SqlParameter("@SalaryDate", dtSalaryDate.Value.ToString("Y"));
                            if (DataAccess.SpExecuteQuery("SpSalary", prm) == 1)
                            {
                                SqlParameter[] prmm = new SqlParameter[4];
                                prmm[0] = new SqlParameter("@Type", 1);
                                prmm[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is given This Salary :\'" + txtAmount.Text + "\' To This Trainer :\'" + ddlTrainerName.Text + "(" + ddlTrainerName.SelectedValue + ")\' SuccessFully");
                                prmm[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prmm[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prmm);
                            }
                        }
                    }
                }
                SalaryId = 0;
            }
        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtAmount.Text.Length <= 20)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) & e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.KeyChar != 8)
                {
                    e.Handled = true;
                }
            }
        }

        private void ddlTrainerName_TextChanged(object sender, EventArgs e)
        {
            if (ddlTrainerName.Text != "")
            {
                lblTrainerName.Text = "";
            }
        }

        private void ddlTrainerName_SelectionChangeCommitted(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[3];
            prm[0] = new SqlParameter("@Type", 4);
            prm[1] = new SqlParameter("@TrainerId", ddlTrainerName.SelectedValue);
            prm[2] = new SqlParameter("@Status", 1);
            DataTable dt = DataAccess.SpGetData("SpTrainer", prm);
            if (dt.Rows[0]["TrainerType"].ToString() == "Personal")
            {
                prm[0] = new SqlParameter("@Type", 7);//This Type is in SpCustomer
                prm[1] = new SqlParameter("@TrainerId", ddlTrainerName.SelectedValue);
                prm[2] = new SqlParameter("@Status", 1);
                dt = DataAccess.SpGetData("SpCustomer", prm);
                int TotalCustomer = Convert.ToInt32(dt.Rows[0]["TotalCustomers"]);
                if (TotalCustomer > 0)
                {
                    TotalCustomer = TotalCustomer * 500;
                    txtAmount.Text = "" + (20000 + TotalCustomer);
                }
                else
                {
                    txtAmount.Text = "20000";
                }
            }
            else
            {
                txtAmount.Text = "20000";
            }
        }

        private void ddlTrainerName_Click(object sender, EventArgs e)
        {
            LoadTrainer();
        }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
            if (txtAmount.Text != "")
            {
                lblAmount.Text = "";
            }
        }
    }
}
