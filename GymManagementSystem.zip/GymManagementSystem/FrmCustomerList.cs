﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmCustomerList : Form
    {
        public FrmCustomerList()
        {
            InitializeComponent();
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@Type", 4);
            dgvCustomerList.DataSource = DataAccess.SpGetData("SpCustomer", prm);
            if (FrmLogin.UserRole == "Operator")
            {
                dgvCustomerList.Columns[0].Visible = false;
                dgvCustomerList.Columns[1].Visible = false;
            }
        }

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            FrmCustomer obj = new FrmCustomer();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvCustomerList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                {
                    int CustomerId = Convert.ToInt32(dgvCustomerList.Rows[e.RowIndex].Cells["CustomerId"].Value);
                    if (CustomerId > 0)
                    {
                        if (ConfirmationClass.MESSAGE == DialogResult.Yes)
                        {
                            SqlParameter[] prm = new SqlParameter[2];
                            prm[0] = new SqlParameter("@Type", 3);//for Deletion
                            prm[1] = new SqlParameter("@CustomerId", CustomerId);
                            if (DataAccess.SpExecuteQuery("SpCustomer", prm) == 1)
                            {
                                SqlParameter[] prm1 = new SqlParameter[4];
                                prm1[0] = new SqlParameter("@Type", 1);
                                prm1[1] = new SqlParameter("@UserId", FrmLogin.UserId);
                                prm1[2] = new SqlParameter("@Log", FrmLogin.UserName + "  is Deleted This User:\'" + dgvCustomerList.Rows[e.RowIndex].Cells["CustomerName"].Value.ToString() + "\' Record SuccessFully");
                                prm1[3] = new SqlParameter("@DateTime", DateTime.Now);
                                DataAccess.SpExecuteQuery("SpLog", prm1);
                            }
                            SqlParameter[] prmm = new SqlParameter[1];
                            prmm[0] = new SqlParameter("@Type", 4);
                            dgvCustomerList.DataSource = DataAccess.SpGetData("SpCustomer", prmm);
                        }
                    }
                }
                else if (e.ColumnIndex == 1)
                {
                    FrmCustomer obj = new FrmCustomer();
                    obj.Edit(dgvCustomerList.Rows[e.RowIndex].Cells["CustomerId"].Value.ToString(), dgvCustomerList.Rows[e.RowIndex].Cells["CustomerName"].Value.ToString(), dgvCustomerList.Rows[e.RowIndex].Cells["CustomerContact"].Value.ToString(), dgvCustomerList.Rows[e.RowIndex].Cells["CustomerCnic"].Value.ToString(), dgvCustomerList.Rows[e.RowIndex].Cells["CustomerWeight"].Value.ToString(), dgvCustomerList.Rows[e.RowIndex].Cells["CustomerGender"].Value.ToString(), dgvCustomerList.Rows[e.RowIndex].Cells["TrainerId"].Value.ToString(), dgvCustomerList.Rows[e.RowIndex].Cells["CustomerAddress"].Value.ToString(),Convert.ToInt32(dgvCustomerList.Rows[e.RowIndex].Cells["CustomerAge"].Value), Convert.ToInt32(dgvCustomerList.Rows[e.RowIndex].Cells["Status"].Value));
                    obj.ShowDialog();
                    this.Close();
                }
            }
            catch
            {

            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 6);//Type 6 for searching
            prm[1] = new SqlParameter("@CustomerName", txtName.Text);
            dgvCustomerList.DataSource = DataAccess.SpGetData("SpCustomer", prm);
        }

        private void txtContact_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 6);//Type 6 for searching
            prm[1] = new SqlParameter("@CustomerContact", txtContact.Text);
            dgvCustomerList.DataSource = DataAccess.SpGetData("SpCustomer", prm);
        }

        private void txtCnic_TextChanged(object sender, EventArgs e)
        {
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@Type", 6);//Type 6 for searching
            prm[1] = new SqlParameter("@CustomerCnic", txtCnic.Text);
            dgvCustomerList.DataSource = DataAccess.SpGetData("SpCustomer", prm);
        }
    }
}
