﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
            if (FrmLogin.UserRole == "Operator")
            {
                aboutUsToolStripMenuItem.Visible = false;
                machineUseListToolStripMenuItem.Visible = false;
            }
        }
        private void treeView1_Click(object sender, EventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }
        private void customerListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCustomerList obj = new FrmCustomerList();
            obj.ShowDialog();
        }
        private void trainerListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmTrainerList obj = new FrmTrainerList();
            obj.ShowDialog();
        }

        private void paymentListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmPaymentList obj = new FrmPaymentList();
            obj.ShowDialog();
        }

        private void salaryListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmSalaryList obj = new FrmSalaryList();
            obj.ShowDialog();
        }

        private void expenseListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExpenseList obj = new FrmExpenseList();
            obj.ShowDialog();
        }

        private void expenseHeadListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExpenseHeadList obj = new FrmExpenseHeadList();
            obj.ShowDialog();
        }

        private void machineListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMachineList obj = new FrmMachineList();
            obj.ShowDialog();
        }

        //private void contactUsToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    FrmContactUs obj = new FrmContactUs();
        //    obj.ShowDialog();
        //}

        private void aboutUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAboutUs obj = new FrmAboutUs();
            obj.ShowDialog();
        }
     
        private void toolStripMachineList_Click(object sender, EventArgs e)
        {
            FrmMachineList obj = new FrmMachineList();
            obj.ShowDialog();
        }

        private void UserListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmUserList obj = new FrmUserList();
            obj.ShowDialog();
        }

        private void logListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmLog obj = new FrmLog();
            obj.ShowDialog();
        }

        private void machineUseListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMachineUseList obj = new FrmMachineUseList();
            obj.ShowDialog();
        }
    }
}
