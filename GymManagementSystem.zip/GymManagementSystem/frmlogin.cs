﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void lblChangePassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmChangePassword obj = new FrmChangePassword();
            obj.ShowDialog();
            this.Close();
        }
        private void lblForgetPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmGenerateOtp obj = new FrmGenerateOtp();
            obj.ShowDialog();
            this.Close();
        }
        //int a;
        private void FrmLogin_Load(object sender, EventArgs e)
        {
            //if (a <= 20)
            //{
            //    a++;
            //    FrmLoading obj = new FrmLoading();
            //    obj.ShowDialog();
            //    this.Close();
            //}
            //else
            //{
            //    timer1.Enabled = false;
            //    FrmLogin obj = new FrmLogin();
            //    obj.ShowDialog();
            //    this.Close();
            //}
        }

        private void btnCross_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        public static string UserRole, UserName;
        public static int UserId;

        private void txtUserNameEmailContact_TextChanged(object sender, EventArgs e)
        {
            if (txtUserNameEmailContact.Text != "")
            {
                lblUserNameEmailContact.Text = "";
            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtPassword.Text != "")
            {
                lblPassword.Text = "";
            }
        }
        int i = 0;
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            if (i==0)
            {
                txtPassword.PasswordChar = '\0';
                btnShowHide.BackgroundImage = global::GymManagementSystem.Properties.Resources.icons8_eye_24px_5;
                i = 1;
            }
            else
            {
                txtPassword.PasswordChar = '*';
                btnShowHide.BackgroundImage = global::GymManagementSystem.Properties.Resources.icons8_eye_24px_2;
                i = 0;
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUserNameEmailContact.Text == "")
            {
                lblUserNameEmailContact.Text = "Required";
                txtUserNameEmailContact.Focus();
            }
            else if (txtPassword.Text == "")
            {
                lblPassword.Text = "Required";
                txtPassword.Focus();
            }
            else
            {
                SqlParameter[] prm = new SqlParameter[4];
                prm[0] = new SqlParameter("@Type", 7);//For Login
                prm[1] = new SqlParameter("@UserName", txtUserNameEmailContact.Text);
                prm[2] = new SqlParameter("@Email", txtUserNameEmailContact.Text);
                prm[3] = new SqlParameter("@Contact", txtUserNameEmailContact.Text);
                DataTable dt = DataAccess.SpGetData("SpUser", prm);
                if (dt.Rows.Count > 0)
                {
                    SqlParameter[] prmm = new SqlParameter[5];
                    prmm[0] = new SqlParameter("@Type", 10);//For Login
                    prmm[1] = new SqlParameter("@UserName", txtUserNameEmailContact.Text);
                    prmm[2] = new SqlParameter("@Email", txtUserNameEmailContact.Text);
                    prmm[3] = new SqlParameter("@Contact", txtUserNameEmailContact.Text);
                    prmm[4] = new SqlParameter("@Password", txtPassword.Text);
                    dt = DataAccess.SpGetData("SpUser", prmm);
                    if (dt.Rows.Count > 0)
                    {
                        UserId = Convert.ToInt32(dt.Rows[0]["UserId"]);
                        UserRole = "" + dt.Rows[0]["UserRole"];
                        UserName = "" + dt.Rows[0]["UserName"];
                        SqlParameter[] prm1 = new SqlParameter[4];
                        prm1[0] = new SqlParameter("@Type", 1);
                        prm1[1] = new SqlParameter("@UserId", UserId);
                        prm1[2] = new SqlParameter("@Log", "This User:\'" + UserName + "\' is Login SuccessFully");
                        prm1[3] = new SqlParameter("@DateTime", DateTime.Now);
                        DataAccess.SpExecuteQuery("SpLog", prm1);
                        FrmMain obj = new FrmMain();
                        obj.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Incorrect Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Incorrect UserName or Contact or Email", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
