﻿using GymManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class FrmForgetPassword : Form
    {
        public FrmForgetPassword()
        {
            InitializeComponent();
        }


        private void lblGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin obj = new FrmLogin();
            obj.ShowDialog();
            this.Close();
        }

        private void btnCross_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            if (txtOtp.Text == "")
            {
                lblOtp.Text = "Required";
                txtOtp.Focus();
            }
            else if (txtNewPassword.Text == "")
            {
                lblNewPassword.Text = "Required";
                txtNewPassword.Focus();
            }
            else if (txtConfirmPassword.Text == "")
            {
                lblConfirmPassword.Text = "Required";
                txtConfirmPassword.Focus();
            }
            else
            {
                if (txtNewPassword.Text == txtConfirmPassword.Text)
                {
                    if (txtOtp.Text == FrmGenerateOtp.Otp)
                    {

                        SqlParameter[] prm = new SqlParameter[4];
                        prm[0] = new SqlParameter("@Type", 11);//Change password based on OTP and EMAIL
                        prm[1] = new SqlParameter("@Email", FrmGenerateOtp.Email);
                        prm[2] = new SqlParameter("@Otp", FrmGenerateOtp.Otp);
                        prm[3] = new SqlParameter("@Password", txtConfirmPassword.Text);
                        if(DataAccess.SpExecuteQuery("SpUser", prm)==1)
                        {
                            SqlParameter[] prm1 = new SqlParameter[4];
                            prm1[0] = new SqlParameter("@Type", 1);
                            prm1[1] = new SqlParameter("@UserId", FrmGenerateOtp.UserId);
                            prm1[2] = new SqlParameter("@Log", FrmGenerateOtp.UserName + "  is Forget Password SuccessFully");
                            prm1[3] = new SqlParameter("@DateTime", DateTime.Now);
                            DataAccess.SpExecuteQuery("SpLog", prm1);
                        }
                        else
                        {
                            MessageBox.Show("Password not Changed");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Incorrec Otp Code", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("New Password and Confirm Password are not same", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtOtp_TextChanged(object sender, EventArgs e)
        {
            if (txtOtp.Text != "")
            {
                lblOtp.Text = "";
            }
        }

        private void txtNewPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtNewPassword.Text != "")
            {
                lblNewPassword.Text = "";
            }
        }

        private void txtConfirmPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtConfirmPassword.Text != "")
            {
                lblConfirmPassword.Text = "";
            }
        }
    }
}
